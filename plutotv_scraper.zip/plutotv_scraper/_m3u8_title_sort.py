import sys

def sort_m3u8_by_title(input_file):
    with open(input_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    header = []
    tracks = []
    current_extinf = None

    for line in lines:
        line_strip = line.strip()
        if not line_strip:
            continue
            
        # Keep global headers
        if line_strip.startswith('#EXTM3U') or line_strip.startswith('#EXT-X'):
            header.append(line_strip)
        # Store the metadata line
        elif line_strip.startswith('#EXTINF'):
            current_extinf = line_strip
        # Capture the URL line and pair it with the stored metadata
        else:
            title = ""
            if current_extinf and ',' in current_extinf:
                # Split from the right side to find the last comma
                title = current_extinf.rsplit(',', 1)[-1].strip()
            else:
                title = line_strip
                
            tracks.append((title, current_extinf, line_strip))
            current_extinf = None

    # FIX: Explicitly target the first element (the title string) for lowercasing
    tracks.sort(key=lambda x: x[0].lower())

    # Output the sorted results
    for h in header:
        print(h)
    for title, extinf, track in tracks:
        if extinf:
            print(extinf)
        print(track)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python3 script.py <playlist.m3u8>")
        sys.exit(1)
    sort_m3u8_by_title(sys.argv[1])
