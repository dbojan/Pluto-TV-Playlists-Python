#!/usr/bin/env python3
"""
plutotv-scraper — Python port of https://github.com/4v3ngR/pluto_tv_scraper
Zero external dependencies — uses only the Python standard library.
"""

import sys
import time
import logging
import argparse

from lib.config import Config
from lib import plutotv

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="plutotv-scraper",
        description="Generate M3U8 playlists and XMLTV EPG files for Pluto TV.",
        add_help=False,
    )
    p.add_argument("--config",               metavar="FILE",          help="Path to config JSON file (default: config.json)")
    p.add_argument("--mapping",              metavar="REGION,IP",     help="Single region+IP override, e.g. us,45.50.96.71")
    p.add_argument("--outdir",               metavar="DIR",           help="Output directory")
    p.add_argument("--clientid",             metavar="UUID",          help="Pluto TV client ID (UUID)")
    p.add_argument("--all",                  action="store_true",     help="Merge all regions into a single playlist/EPG")
    p.add_argument("--chno",                 metavar="N",  type=int,  help="Start channel numbering at N")
    p.add_argument("--group",                metavar="MODE", choices=["genre","country"], help="Playlist grouping: genre or country")
    p.add_argument("--regionalize",          action="store_true",     help="Append region code to channel IDs")
    p.add_argument("--exclude-groups",       metavar="REGEX",         help="Exclude groups matching regex")
    p.add_argument("--exclude-channels",     metavar="REGEX",         help="Exclude channels matching regex")
    p.add_argument("--port",                 metavar="N",  type=int,  help="Serve generated files on this port")
    p.add_argument("--refresh",              metavar="SEC", type=int, help="Re-fetch interval in seconds (min 3600)")
    p.add_argument("--unique-clientid",      action="store_true",     help="Generate unique client ID per server request")
    p.add_argument("--random-clientid",      action="store_true",     help="Generate random client ID per request")
    p.add_argument("--x-tvg-url",            metavar="URL",           help="Custom x-tvg-url in EXTM3U header")
    p.add_argument("--ondemand",             action="store_true",     help="Also generate on-demand movie playlists")
    p.add_argument("--vlcopts",              action="store_true",     help="Add #EXTVLCOPT entries to M3U8")
    p.add_argument("--pipeopts",             action="store_true",     help="Append piped headers to stream URLs")
    p.add_argument("--json-source",          metavar="FILE",          help="Public JSON file used as backup for regions where the live API returns no data")
    p.add_argument("--append-expiry",        action="store_true",     help="Append #list updated / jwt expiry timestamps as comments to M3U8")
    p.add_argument("-h", "--help",           action="store_true",     help="Show this help message and exit")
    p.add_argument("--no-xml", action="store_true", help="Skip writing XMLTV EPG files (very time-consuming), for channels only, not vod")
    return p


def main():
    if sys.version_info < (3, 8):
        print("ERROR: Python 3.8 or newer required.", file=sys.stderr)
        sys.exit(1)

    parser = build_parser()
    args   = parser.parse_args()

    if args.help:
        parser.print_help()
        sys.exit(0)

    cfg = Config(args)
    cfg.load()

    port    = cfg.get("port")
    refresh = cfg.get("refresh")

    if refresh and refresh < 3600:
        log.error("Refresh interval must be at least 3600 seconds.")
        sys.exit(1)

    if port and refresh:
        from lib.server import serve
        import threading
        def refresh_loop():
            while True:
                time.sleep(refresh)
                log.info("Refreshing playlists …")
                try:
                    plutotv.process(cfg)
                except Exception as exc:
                    log.error("Refresh failed: %s", exc)

        plutotv.process(cfg)
        t = threading.Thread(target=refresh_loop, daemon=True)
        t.start()
        serve(cfg)

    elif port:
        from lib.server import serve
        serve(cfg)

    else:
        plutotv.process(cfg)


if __name__ == "__main__":
    main()
