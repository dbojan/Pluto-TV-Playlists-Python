"""
Pluto TV API calls and playlist/EPG generators.
Uses only stdlib (urllib) — zero external dependencies.
"""

import json
import logging
import re
import ssl
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from typing import Optional

from lib.utils import escape_html, get_time_str

log = logging.getLogger(__name__)

USERAGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) "
    "Version/14.1.2 Safari/605.1.15"
)
APP_VERSION = "7.9.0-a9cca6b89aea4dc0998b92a51989d2adb9a9025d"

# SSL context that doesn't verify certs (same as the JS code's behaviour)
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE


def _get(url: str, extra_headers: Optional[dict] = None) -> dict:
    """HTTP GET → parsed JSON. Pure stdlib."""
    headers = {"User-Agent": USERAGENT}
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, context=_SSL_CTX, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


class PlutoAPI:
    """Stateful API client for one region fetch cycle."""

    def __init__(self):
        self.boot_data: Optional[dict] = None
        self.channel_list: Optional[dict] = None
        self.category_list: Optional[dict] = None
        self.timeline_list: Optional[dict] = None

    # context-manager no-ops (kept so callers don't need changing)
    def __enter__(self):  return self
    def __exit__(self, *_): pass

    def _headers(self, xff: Optional[str] = None) -> dict:
        h = {}
        if xff:
            h["X-Forwarded-For"] = xff
        return h

    def _auth_headers(self, xff: Optional[str] = None) -> dict:
        h = self._headers(xff)
        h["Authorization"] = f"Bearer {self.boot_data['sessionToken']}"
        return h

    # ------------------------------------------------------------------
    # Boot
    # ------------------------------------------------------------------

    def boot(self, xff: Optional[str], client_id: str) -> dict:
        now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        url = (
            "https://boot.pluto.tv/v4/start"
            f"?appName=web&appVersion={APP_VERSION}"
            "&deviceVersion=16.2.0&deviceModel=web&deviceMake=Chrome&deviceType=web"
            f"&clientID={client_id}&clientModelNumber=1.0.0"
            "&channelID=5a4d3a00ad95e4718ae8d8db&serverSideAds=true"
            f"&constraints=&drmCapabilities=&blockingMode=&clientTime={now}"
        )
        self.boot_data = _get(url, self._headers(xff))
        return self.boot_data

    # ------------------------------------------------------------------
    # Channels
    # ------------------------------------------------------------------

    def channels(self, xff: Optional[str]) -> dict:
        url = (
            "https://service-channels.clusters.pluto.tv/v2/guide/channels"
            "?channelIds=&offset=0&limit=1000&sort=number%3Aasc"
        )
        self.channel_list = _get(url, self._auth_headers(xff))
        return self.channel_list

    # ------------------------------------------------------------------
    # Categories
    # ------------------------------------------------------------------

    def categories(self, xff: Optional[str]) -> dict:
        url = "https://service-channels.clusters.pluto.tv/v2/guide/categories"
        self.category_list = _get(url, self._auth_headers(xff))
        return self.category_list

    # ------------------------------------------------------------------
    # Timelines
    # ------------------------------------------------------------------

    def timelines(self, xff: Optional[str]) -> dict:
        channel_ids = [c["id"] for c in self.channel_list["data"]]
        chunk_size  = 30
        self.timeline_list = {"data": []}

        for offset_h in range(-1, 24, 4):
            window_start = datetime.now(timezone.utc) + timedelta(hours=offset_h)
            client_time  = window_start.isoformat().replace("+00:00", "Z")

            for i in range(0, len(channel_ids), chunk_size):
                chunk     = channel_ids[i: i + chunk_size]
                ids_param = "%2C".join(chunk)
                url = (
                    "https://service-channels.clusters.pluto.tv/v2/guide/timelines"
                    f"?start={client_time}&duration=240&channelIds={ids_param}"
                )
                data = _get(url, self._auth_headers(xff))
                self.timeline_list["data"].extend(data.get("data", []))

        return self.timeline_list

    # ------------------------------------------------------------------
    # Generate M3U8
    # ------------------------------------------------------------------

    def generate_m3u8(
        self,
        region: str,
        group: str,
        regionalize: bool,
        exclude_groups: Optional[str],
        exclude_channels: Optional[str],
        chno,
        x_tvg_url: Optional[str],
        vlcopts: bool,
        xff: Optional[str],
        pipeopts: bool,
    ) -> tuple:
        """Returns (m3u8_text, num_channels)."""

        m3u8 = f'#EXTM3U x-tvg-url="{x_tvg_url}"\n\n' if x_tvg_url else "#EXTM3U\n\n"
        num_channels = 0

        for c in self.channel_list["data"]:
            if not c.get("categoryIDs"):
                log.warning("Channel has no categoryIDs: %s %s", c.get("id"), c.get("name"))
                continue

            category = next(
                (cat for cat in self.category_list["data"] if cat["id"] == c["categoryIDs"][0]),
                None,
            )
            if category is None:
                continue

            catname = category["name"] if group == "genre" else region

            if exclude_groups   and re.search(exclude_groups,   category["name"]): continue
            if exclude_channels and re.search(exclude_channels, c["name"]):        continue

            tvg_chno = chno if chno is not None else c.get("number", "")
            tvg_id   = c["id"] + (f"-{region}" if regionalize and region else "")
            url = (
                f"{self.boot_data['servers']['stitcher']}/v2{c['stitched']['path']}"
                f"?{self.boot_data['stitcherParams']}"
                f"&jwt={self.boot_data['sessionToken']}&masterJWTPassthrough=true"
            )

            if vlcopts:
                if xff: m3u8 += f"#EXTVLCOPT:http-referrer={xff}\n"
                m3u8 += f"#EXTVLCOPT:http-user-agent={USERAGENT}\n"
            elif pipeopts:
                if xff: url += f'|x-forwarded-for="{xff}"'
                url += f'|http-user-agent="{USERAGENT}"'

            logo = c["images"][0]["url"] if c.get("images") else ""
            m3u8 += (
                f'#EXTINF:-1 tvg-id="{tvg_id}" tvg-logo="{logo}" '
                f'tvg-chno="{tvg_chno}" group-title="{catname}", {c["name"]}\n'
                f'{url}\n\n'
            )
            if chno is not None: chno += 1
            num_channels += 1

        return m3u8, num_channels

    # ------------------------------------------------------------------
    # Generate XMLTV
    # ------------------------------------------------------------------

    def generate_xmltv(self, region: str, regionalize: bool) -> str:
        root = ET.Element("tv", {"source-info-name": "nobody,xmltv.net,nzxmltv.com"})

        for c in self.channel_list["data"]:
            if not c.get("categoryIDs"):
                continue
            ch_id = c["id"] + (f"-{region}" if regionalize and region else "")
            ch_el = ET.SubElement(root, "channel", {"id": ch_id})
            ET.SubElement(ch_el, "display-name").text = c["name"]
            ET.SubElement(ch_el, "lcn").text = str(c.get("number", ""))
            if c.get("images"):
                ET.SubElement(ch_el, "icon", {"src": escape_html(c["images"][0]["url"])})

        for t in self.timeline_list["data"]:
            ch_id     = t["channelId"] + (f"-{region}" if regionalize else "")
            timelines = sorted(t.get("timelines", []), key=lambda x: x.get("start", ""))
            for entry in timelines:
                start_dt = datetime.fromisoformat(entry["start"].replace("Z", "+00:00"))
                stop_dt  = datetime.fromisoformat(entry["stop"].replace("Z", "+00:00"))
                prog = ET.SubElement(root, "programme", {
                    "channel": ch_id,
                    "start":   f"{get_time_str(start_dt)} +0000",
                    "stop":    f"{get_time_str(stop_dt)} +0000",
                })
                ET.SubElement(prog, "title").text = entry.get("title", "")
                try:    desc = entry["episode"]["description"]
                except: desc = ""
                ET.SubElement(prog, "desc").text = desc
                try:    icon_path = entry["episode"]["series"]["tile"]["path"]
                except: icon_path = ""
                if icon_path:
                    ET.SubElement(prog, "icon", {"src": escape_html(icon_path)})

        ET.indent(root, space="    ")
        header = '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE tv SYSTEM "xmltv.dtv">\n'
        return header + ET.tostring(root, encoding="unicode")
