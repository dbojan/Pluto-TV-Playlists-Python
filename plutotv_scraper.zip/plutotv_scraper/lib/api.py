"""
Pluto TV API calls and playlist/EPG generators.
Uses only stdlib (urllib) — zero external dependencies.
"""

import json
import logging
import re
import ssl
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from typing import Optional

from lib.utils import escape_html, get_time_str

log = logging.getLogger(__name__)

USERAGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) "
    "Version/14.1.2 Safari/605.1.15"
)
APP_VERSION = "7.9.0-a9cca6b89aea4dc0998b92a51989d2adb9a9025d"

# SSL context that doesn't verify certs (same as the JS code's behaviour)
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE


def _get(url: str, extra_headers: Optional[dict] = None) -> dict:
    """HTTP GET → parsed JSON. Pure stdlib."""
    headers = {"User-Agent": USERAGENT}
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, context=_SSL_CTX, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


class PlutoAPI:
    """Stateful API client for one region fetch cycle."""

    def __init__(self):
        self.boot_data: Optional[dict] = None
        self.channel_list: Optional[dict] = None
        self.category_list: Optional[dict] = None
        self.timeline_list: Optional[dict] = None

    # context-manager no-ops (kept so callers don't need changing)
    def __enter__(self):  return self
    def __exit__(self, *_): pass

    def _headers(self, xff: Optional[str] = None) -> dict:
        h = {}
        if xff:
            h["X-Forwarded-For"] = xff
        return h

    def _auth_headers(self, xff: Optional[str] = None) -> dict:
        h = self._headers(xff)
        h["Authorization"] = f"Bearer {self.boot_data['sessionToken']}"
        return h

    # ------------------------------------------------------------------
    # Boot
    # ------------------------------------------------------------------

    def boot(self, xff: Optional[str], client_id: str) -> dict:
        now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        url = (
            "https://boot.pluto.tv/v4/start"
            f"?appName=web&appVersion={APP_VERSION}"
            "&deviceVersion=16.2.0&deviceModel=web&deviceMake=Chrome&deviceType=web"
            f"&clientID={client_id}&clientModelNumber=1.0.0"
            "&channelID=5a4d3a00ad95e4718ae8d8db&serverSideAds=true"
            f"&constraints=&drmCapabilities=&blockingMode=&clientTime={now}"
        )
        self.boot_data = _get(url, self._headers(xff))
        return self.boot_data

    # ------------------------------------------------------------------
    # Channels
    # ------------------------------------------------------------------

    def channels(self, xff: Optional[str]) -> dict:
        url = (
            "https://service-channels.clusters.pluto.tv/v2/guide/channels"
            "?channelIds=&offset=0&limit=1000&sort=number%3Aasc"
        )
        self.channel_list = _get(url, self._auth_headers(xff))
        return self.channel_list

    # ------------------------------------------------------------------
    # Categories
    # ------------------------------------------------------------------

    def categories(self, xff: Optional[str]) -> dict:
        url = "https://service-channels.clusters.pluto.tv/v2/guide/categories"
        self.category_list = _get(url, self._auth_headers(xff))
        return self.category_list

    # ------------------------------------------------------------------
    # Timelines
    # ------------------------------------------------------------------

    def timelines(self, xff: Optional[str]) -> dict:
        channel_ids = [c["id"] for c in self.channel_list["data"]]
        chunk_size  = 30
        self.timeline_list = {"data": []}

        for offset_h in range(-1, 24, 4):
            window_start = datetime.now(timezone.utc) + timedelta(hours=offset_h)
            client_time  = window_start.isoformat().replace("+00:00", "Z")

            for i in range(0, len(channel_ids), chunk_size):
                chunk     = channel_ids[i: i + chunk_size]
                ids_param = "%2C".join(chunk)
                url = (
                    "https://service-channels.clusters.pluto.tv/v2/guide/timelines"
                    f"?start={client_time}&duration=240&channelIds={ids_param}"
                )
                data = _get(url, self._auth_headers(xff))
                self.timeline_list["data"].extend(data.get("data", []))

        return self.timeline_list

    # ------------------------------------------------------------------
    # Generate M3U8
    # ------------------------------------------------------------------

    def generate_m3u8(
        self,
        region: str,
        group: str,
        regionalize: bool,
        exclude_groups: Optional[str],
        exclude_channels: Optional[str],
        chno,
        x_tvg_url: Optional[str],
        vlcopts: bool,
        xff: Optional[str],
        pipeopts: bool,
    ) -> tuple:
        """Returns (m3u8_text, num_channels)."""

        m3u8 = f'#EXTM3U x-tvg-url="{x_tvg_url}"\n\n' if x_tvg_url else "#EXTM3U\n\n"
        num_channels = 0

        for c in self.channel_list["data"]:
            if not c.get("categoryIDs"):
                log.warning("Channel has no categoryIDs: %s %s", c.get("id"), c.get("name"))
                continue

            category = next(
                (cat for cat in self.category_list["data"] if cat["id"] == c["categoryIDs"][0]),
                None,
            )
            if category is None:
                continue

            catname = category["name"] if group == "genre" else region

            if exclude_groups   and re.search(exclude_groups,   category["name"]): continue
            if exclude_channels and re.search(exclude_channels, c["name"]):        continue

            tvg_chno = chno if chno is not None else c.get("number", "")
            tvg_id   = c["id"] + (f"-{region}" if regionalize and region else "")
            url = (
                f"{self.boot_data['servers']['stitcher']}/v2{c['stitched']['path']}"
                f"?{self.boot_data['stitcherParams']}"
                f"&jwt={self.boot_data['sessionToken']}&masterJWTPassthrough=true"
            )

            if vlcopts:
                if xff: m3u8 += f"#EXTVLCOPT:http-referrer={xff}\n"
                m3u8 += f"#EXTVLCOPT:http-user-agent={USERAGENT}\n"
            elif pipeopts:
                if xff: url += f'|x-forwarded-for="{xff}"'
                url += f'|http-user-agent="{USERAGENT}"'

            logo = c["images"][0]["url"] if c.get("images") else ""
            m3u8 += (
                f'#EXTINF:-1 tvg-id="{tvg_id}" tvg-logo="{logo}" '
                f'tvg-chno="{tvg_chno}" group-title="{catname}", {c["name"]}\n'
                f'{url}\n\n'
            )
            if chno is not None: chno += 1
            num_channels += 1

        return m3u8, num_channels

    # ------------------------------------------------------------------
    # Generate XMLTV
    # ------------------------------------------------------------------

    def generate_xmltv(self, region: str, regionalize: bool) -> str:
        root = ET.Element("tv", {"source-info-name": "nobody,xmltv.net,nzxmltv.com"})

        for c in self.channel_list["data"]:
            if not c.get("categoryIDs"):
                continue
            ch_id = c["id"] + (f"-{region}" if regionalize and region else "")
            ch_el = ET.SubElement(root, "channel", {"id": ch_id})
            ET.SubElement(ch_el, "display-name").text = c["name"]
            ET.SubElement(ch_el, "lcn").text = str(c.get("number", ""))
            if c.get("images"):
                ET.SubElement(ch_el, "icon", {"src": escape_html(c["images"][0]["url"])})

        for t in self.timeline_list["data"]:
            ch_id     = t["channelId"] + (f"-{region}" if regionalize else "")
            timelines = sorted(t.get("timelines", []), key=lambda x: x.get("start", ""))
            for entry in timelines:
                start_dt = datetime.fromisoformat(entry["start"].replace("Z", "+00:00"))
                stop_dt  = datetime.fromisoformat(entry["stop"].replace("Z", "+00:00"))
                prog = ET.SubElement(root, "programme", {
                    "channel": ch_id,
                    "start":   f"{get_time_str(start_dt)} +0000",
                    "stop":    f"{get_time_str(stop_dt)} +0000",
                })
                ET.SubElement(prog, "title").text = entry.get("title", "")
                try:    desc = entry["episode"]["description"]
                except: desc = ""
                ET.SubElement(prog, "desc").text = desc
                try:    icon_path = entry["episode"]["series"]["tile"]["path"]
                except: icon_path = ""
                if icon_path:
                    ET.SubElement(prog, "icon", {"src": escape_html(icon_path)})

        ET.indent(root, space="    ")
        header = '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE tv SYSTEM "xmltv.dtv">\n'
        return header + ET.tostring(root, encoding="unicode")


# ---------------------------------------------------------------------------
# JSON-source generator (for regions like NO/SE served via external JSON)
# ---------------------------------------------------------------------------

def generate_m3u8_from_json(
    region_data: dict,
    region: str,
    boot_data: dict,
    group: str,
    regionalize: bool,
    exclude_groups,
    exclude_channels,
    chno,
    x_tvg_url,
    vlcopts: bool,
    xff,
    pipeopts: bool,
) -> tuple:
    """
    Build M3U8 from pre-baked JSON channel data (no live channel/category API needed).
    Stream URLs are constructed from the boot_data stitcher, same as the live path.
    Returns (m3u8_text, num_channels).
    """
    import re as _re

    m3u8 = f'#EXTM3U x-tvg-url="{x_tvg_url}"\n\n' if x_tvg_url else "#EXTM3U\n\n"
    num_channels = 0

    for ch_id, c in region_data["channels"].items():
        catname = c.get("group", region) if group == "genre" else region

        if exclude_groups   and _re.search(exclude_groups,   catname):          continue
        if exclude_channels and _re.search(exclude_channels, c.get("name","")): continue

        tvg_chno = chno if chno is not None else c.get("chno", "")
        tvg_id   = ch_id + (f"-{region}" if regionalize and region else "")

        url = (
            f"{boot_data['servers']['stitcher']}/v2/stitch/hls/channel/{ch_id}/master.m3u8"
            f"?{boot_data['stitcherParams']}"
            f"&jwt={boot_data['sessionToken']}&masterJWTPassthrough=true"
        )

        if vlcopts:
            if xff: m3u8 += f"#EXTVLCOPT:http-referrer={xff}\n"
            m3u8 += f"#EXTVLCOPT:http-user-agent={USERAGENT}\n"
        elif pipeopts:
            if xff: url += f'|x-forwarded-for="{xff}"'
            url += f'|http-user-agent="{USERAGENT}"'

        logo = c.get("logo", "")
        m3u8 += (
            f'#EXTINF:-1 tvg-id="{tvg_id}" tvg-logo="{logo}" '
            f'tvg-chno="{tvg_chno}" group-title="{catname}", {c.get("name","")}\n'
            f'{url}\n\n'
        )
        if chno is not None: chno += 1
        num_channels += 1

    return m3u8, num_channels


def generate_xmltv_from_json(
    region_data: dict,
    region: str,
    regionalize: bool,
) -> str:
    """Build XMLTV EPG from pre-baked JSON channel + program data."""
    import xml.etree.ElementTree as _ET
    from datetime import datetime as _dt, timezone as _tz

    root = _ET.Element("tv", {"source-info-name": "nobody,xmltv.net,nzxmltv.com"})

    for ch_id, c in region_data["channels"].items():
        tvg_id = ch_id + (f"-{region}" if regionalize and region else "")
        ch_el  = _ET.SubElement(root, "channel", {"id": tvg_id})
        _ET.SubElement(ch_el, "display-name").text = c.get("name", "")
        _ET.SubElement(ch_el, "lcn").text = str(c.get("chno", ""))
        logo = c.get("logo", "")
        if logo:
            _ET.SubElement(ch_el, "icon", {"src": escape_html(logo)})

    for ch_id, c in region_data["channels"].items():
        tvg_id   = ch_id + (f"-{region}" if regionalize and region else "")
        programs = c.get("programs", [])
        for idx, prog_entry in enumerate(programs):
            start_ts = prog_entry[0]
            title    = prog_entry[1] if len(prog_entry) > 1 else ""
            # stop = next program's start, or start + 30 min for the last one
            if idx + 1 < len(programs):
                stop_ts = programs[idx + 1][0]
            else:
                stop_ts = start_ts + 1800

            start_dt = _dt.fromtimestamp(start_ts, tz=_tz.utc)
            stop_dt  = _dt.fromtimestamp(stop_ts,  tz=_tz.utc)

            prog = _ET.SubElement(root, "programme", {
                "channel": tvg_id,
                "start":   f"{get_time_str(start_dt)} +0000",
                "stop":    f"{get_time_str(stop_dt)} +0000",
            })
            _ET.SubElement(prog, "title").text = title
            _ET.SubElement(prog, "desc").text  = c.get("description", "")
            art = c.get("art", "")
            if art:
                _ET.SubElement(prog, "icon", {"src": escape_html(art)})

    _ET.indent(root, space="    ")
    header = '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE tv SYSTEM "xmltv.dtv">\n'
    return header + _ET.tostring(root, encoding="unicode")


# ---------------------------------------------------------------------------
# Stub generators — build M3U8 / XMLTV from bare channel IDs only.
# Used when both the live API and any JSON sources return nothing for a region
# but the caller has a .txt allowlist of known channel IDs.
# Channel metadata (name, logo, EPG) is intentionally absent; the stream URL
# is constructed identically to generate_m3u8_from_json so tokens stay valid.
# ---------------------------------------------------------------------------

def generate_m3u8_from_ids(
    channel_ids: set,
    region: str,
    boot_data: dict,
    group: str,
    regionalize: bool,
    exclude_channels,          # regex str or None  (groups not applicable here)
    chno,
    x_tvg_url,
    vlcopts: bool,
    xff,
    pipeopts: bool,
) -> tuple:
    """
    Build a minimal M3U8 from a bare set of channel IDs.
    Channel name defaults to the ID itself; no logo, no EPG icon.
    Returns (m3u8_text, num_channels).
    """
    import re as _re

    m3u8 = f'#EXTM3U x-tvg-url="{x_tvg_url}"\n\n' if x_tvg_url else "#EXTM3U\n\n"
    num_channels = 0
    local_chno = chno  # don't mutate the caller's counter here

    for ch_id in sorted(channel_ids):          # sorted for deterministic output
        if exclude_channels and _re.search(exclude_channels, ch_id):
            continue

        tvg_chno = local_chno if local_chno is not None else ""
        tvg_id   = ch_id + (f"-{region}" if regionalize and region else "")
        catname  = region if group == "country" else region   # no category data available

        url = (
            f"{boot_data['servers']['stitcher']}/v2/stitch/hls/channel/{ch_id}/master.m3u8"
            f"?{boot_data['stitcherParams']}"
            f"&jwt={boot_data['sessionToken']}&masterJWTPassthrough=true"
        )

        if vlcopts:
            if xff:
                m3u8 += f"#EXTVLCOPT:http-referrer={xff}\n"
            m3u8 += f"#EXTVLCOPT:http-user-agent={USERAGENT}\n"
        elif pipeopts:
            if xff:
                url += f'|x-forwarded-for="{xff}"'
            url += f'|http-user-agent="{USERAGENT}"'

        m3u8 += (
            f'#EXTINF:-1 tvg-id="{tvg_id}" tvg-logo="" '
            f'tvg-chno="{tvg_chno}" group-title="{catname}", {ch_id}\n'
            f'{url}\n\n'
        )
        if local_chno is not None:
            local_chno += 1
        num_channels += 1

    return m3u8, num_channels


def generate_xmltv_from_ids(
    channel_ids: set,
    region: str,
    regionalize: bool,
) -> str:
    """
    Build a minimal XMLTV document from bare channel IDs.
    No programme data is emitted — players will show an empty guide for
    these channels, which is correct since we have no EPG information.
    """
    import xml.etree.ElementTree as _ET

    root = _ET.Element("tv", {"source-info-name": "nobody,xmltv.net,nzxmltv.com"})

    for ch_id in sorted(channel_ids):
        tvg_id = ch_id + (f"-{region}" if regionalize and region else "")
        ch_el  = _ET.SubElement(root, "channel", {"id": tvg_id})
        _ET.SubElement(ch_el, "display-name").text = ch_id   # ID is the only name we have

    _ET.indent(root, space="    ")
    header = '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE tv SYSTEM "xmltv.dtv">\n'
    return header + _ET.tostring(root, encoding="unicode")
