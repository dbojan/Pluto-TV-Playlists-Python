"""
On-demand (VOD) playlist & EPG generator.
Uses only stdlib (urllib) — zero external dependencies.
"""

import json
import logging
import os
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from typing import Optional

from lib.api import _get, USERAGENT
from lib.utils import escape_html, get_time_str

log = logging.getLogger(__name__)


class OnDemand:
    def __init__(self):
        self.categories_list: Optional[dict] = None

    def _auth_headers(self, boot_data: dict, xff: Optional[str] = None) -> dict:
        h = {"Authorization": f"Bearer {boot_data['sessionToken']}"}
        if xff:
            h["X-Forwarded-For"] = xff
        return h

    def fetch_categories(self, config, region: str, boot_data: dict) -> dict:
        xff = config.get_mapping().get(region)
        url = (
            "https://service-vod.clusters.pluto.tv/v4/vod/categories"
            "?includeItems=false&includeCategoryFields=iconSvg"
            "&offset=1000&page=1&sort=number%3Aasc"
        )
        self.categories_list = _get(url, self._auth_headers(boot_data, xff))
        return self.categories_list

    def _get_items(self, config, region: str, category_id: str, boot_data: dict) -> dict:
        xff = config.get_mapping().get(region)
        url = (
            f"https://service-vod.clusters.pluto.tv/v4/vod/categories"
            f"/{category_id}/items?offset=0&page=1"
        )
        return _get(url, self._auth_headers(boot_data, xff))

    def _get_vod_item(self, config, region: str, item_id: str, boot_data: dict) -> Optional[dict]:
        xff = config.get_mapping().get(region)
        url = f"https://service-vod.clusters.pluto.tv/v4/vod/items?ids={item_id}"
        data = _get(url, self._auth_headers(boot_data, xff))
        return data[0] if data else None

    def generate_m3u8(self, config, region: str, boot_data: dict) -> tuple:
        x_tvg_url = config.get("xtvgurl")
        outdir    = config.get("outdir") or "."
        cachefile = os.path.join(outdir, f"plutotv_ondemand_{region}.cache")

        cache: dict = {}
        try:
            with open(cachefile, "r", encoding="utf-8") as fh:
                cache = json.load(fh)
        except (FileNotFoundError, json.JSONDecodeError):
            cache = {}

        full_tvg_url = None
        if x_tvg_url:
            full_tvg_url = x_tvg_url + (f"plutotv_ondemand_{region}.xml" if str(x_tvg_url).endswith("/") else "")

        m3u8 = f'#EXTM3U x-tvg-url="{full_tvg_url}"\n\n' if full_tvg_url else "#EXTM3U\n\n"
        num_channels = 0
        ch_no = 9000
        new_cache: dict = {}
        cache_dirty = False

        for cat in (self.categories_list or {}).get("categories", []):
            if not cat:
                continue
            log.info("VOD category: %s", cat.get("name"))
            items_data = self._get_items(config, region, cat["_id"], boot_data)
            catname    = items_data.get("name", cat.get("name", ""))

            for item in items_data.get("items", []):
                if item.get("type") != "movie":
                    continue
                item_id   = item["_id"]
                cache_key = f"{item_id}-{region}"

                if cache_key not in cache:
                    cache_dirty = True
                    vod_item = self._get_vod_item(config, region, item_id, boot_data)
                else:
                    vod_item = cache[cache_key]

                if not vod_item:
                    continue

                new_cache[cache_key] = cache[cache_key] = vod_item

                stitched = vod_item.get("stitched", {})
                path = stitched.get("path")
                if not path:
                    for p in stitched.get("paths", []):
                        if p.get("type") == "hls":
                            path = p.get("path")
                            break
                if not path:
                    continue

                url = (
                    f"{boot_data['servers']['stitcher']}/v2{path}"
                    f"?{boot_data['stitcherParams']}"
                    f"&jwt={boot_data['sessionToken']}&masterJWTPassthrough=true"
                )
                logo = vod_item.get("featuredImage", {}).get("path", "")
                m3u8 += (
                    f'#EXTINF:-1 tvg-id="{cache_key}" tvg-logo="{logo}" '
                    f'tvg-chno="{ch_no}" group-title="{catname}", {vod_item.get("name","")}\n'
                    f'{url}\n\n'
                )
                new_cache[cache_key]["stream_url"] = url
                num_channels += 1
                ch_no += 1

                if cache_dirty:
                    try:
                        with open(cachefile, "w", encoding="utf-8") as fh:
                            json.dump(cache, fh)
                        cache_dirty = False
                    except OSError:
                        pass

        try:
            new_cache["categoriesList"] = self.categories_list
            with open(cachefile, "w", encoding="utf-8") as fh:
                json.dump(new_cache, fh)
        except OSError as exc:
            log.warning("Could not write VOD cache: %s", exc)

        return m3u8, num_channels

    def generate_xmltv(self, config, region: str) -> Optional[str]:
        outdir    = config.get("outdir") or "."
        cachefile = os.path.join(outdir, f"plutotv_ondemand_{region}.cache")
        try:
            with open(cachefile, "r", encoding="utf-8") as fh:
                cache = json.load(fh)
        except (FileNotFoundError, json.JSONDecodeError):
            return None

        root     = ET.Element("tv", {"source-info-name": "nobody,xmltv.net,nzxmltv.com"})
        now      = datetime.now(timezone.utc)
        start_dt = now - timedelta(days=1)
        stop_dt  = now + timedelta(days=1)

        for cache_key, entry in cache.items():
            if cache_key == "categoriesList":
                continue
            ch_el = ET.SubElement(root, "channel", {"id": cache_key})
            ET.SubElement(ch_el, "display-name").text = entry.get("name", "")
            logo = entry.get("featuredImage", {}).get("path", "")
            if logo:
                ET.SubElement(ch_el, "icon", {"src": escape_html(logo)})

            prog = ET.SubElement(root, "programme", {
                "channel": cache_key,
                "start":   f"{get_time_str(start_dt)} +0000",
                "stop":    f"{get_time_str(stop_dt)} +0000",
            })
            ET.SubElement(prog, "title").text = entry.get("name", "")
            ET.SubElement(prog, "desc").text  = entry.get("description", "")
            if logo:
                ET.SubElement(prog, "icon", {"src": escape_html(logo)})

        ET.indent(root, space="    ")
        header = '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE tv SYSTEM "xmltv.dtv">\n'
        return header + ET.tostring(root, encoding="unicode")
