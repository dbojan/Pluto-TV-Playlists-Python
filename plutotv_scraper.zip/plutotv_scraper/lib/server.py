"""
server.py
HTTP file server using Python's built-in http.server — zero dependencies.
Serves M3U8/XML files and hot-refreshes JWT tokens in M3U8 responses.
"""

import logging
import os
import re
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional

from lib.api import PlutoAPI
from lib.utils import make_uuid

log = logging.getLogger(__name__)

_MIME = {
    ".m3u8": "application/x-mpegURL; charset=UTF-8",
    ".xml":  "text/xml; charset=UTF-8",
}


def _get_uuid(config, remote_addr: str) -> Optional[str]:
    if config.get("uniqueclientid"):
        return make_uuid(remote_addr)
    if config.get("randomclientid"):
        return make_uuid()
    return None


def _make_handler(config):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            log.info("HTTP %s - %s", self.address_string(), fmt % args)

        def do_GET(self):
            # strip leading slash, block path traversal
            filename = Path(self.path.lstrip("/")).name
            outdir   = config.get("outdir") or "."
            fullpath = os.path.join(outdir, filename)
            ext      = Path(fullpath).suffix.lower()

            try:
                with open(fullpath, "r", encoding="utf-8") as fh:
                    contents = fh.read()
            except FileNotFoundError:
                self.send_error(404, f"Not found: {filename}")
                return
            except OSError as exc:
                self.send_error(500, str(exc))
                return

            mimetype = _MIME.get(ext, "text/plain; charset=UTF-8")

            if ext == ".m3u8":
                remote = self.client_address[0]
                uid    = _get_uuid(config, remote)
                if uid:
                    try:
                        api = PlutoAPI()
                        boot_data = api.boot(None, uid)
                        old_id = config.get("clientid") or ""
                        if old_id:
                            contents = re.sub(
                                re.escape(old_id),
                                boot_data["session"]["sessionID"],
                                contents,
                                flags=re.IGNORECASE,
                            )
                        contents = re.sub(
                            r"jwt=.*?master",
                            f"jwt={boot_data['sessionToken']}&master",
                            contents,
                        )
                    except Exception as exc:
                        log.warning("JWT refresh failed: %s", exc)

            body = contents.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", mimetype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    return Handler


def serve(config) -> None:
    port    = config.get("port") or 8080
    handler = _make_handler(config)
    httpd   = HTTPServer(("0.0.0.0", port), handler)
    log.info("Serving on http://0.0.0.0:%d  (press Ctrl+C to stop)", port)
    httpd.serve_forever()
