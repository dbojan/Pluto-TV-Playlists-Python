"""
Shared utility helpers.
Mirrors lib/utils.js from the original JS project.
"""

import re
import uuid as _uuid_mod
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from typing import Optional

_HTML_ESCAPE_TABLE = str.maketrans({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    '"': "&quot;",
})


def escape_html(s: str) -> str:
    """Escape HTML special characters (mirrors utils.escapeHTML)."""
    return s.translate(_HTML_ESCAPE_TABLE)


def get_time_str(dt: datetime) -> str:
    """Format a datetime as YYYYMMDDHHmmss in UTC (mirrors utils.getTimeStr)."""
    d = dt.astimezone(timezone.utc)
    return (
        f"{d.year}"
        f"{d.month:02d}"
        f"{d.day:02d}"
        f"{d.hour:02d}"
        f"{d.minute:02d}"
        f"{d.second:02d}"
    )


# ---------------------------------------------------------------------------
# UUID helpers (mirrors utils.uuid / utils.hex)
# ---------------------------------------------------------------------------

def _hex_seeded(length: int, seed: str) -> str:
    """Deterministic hex string derived from seed (mirrors hex(len, src))."""
    chrs = seed
    return "".join(chrs[(length + i) % len(chrs)] for i in range(length))


def _hex_random(length: int) -> str:
    """Random hex string (mirrors hex(len) with no src)."""
    import random
    chrs = "1234567890abcdef"
    return "".join(random.choice(chrs) for _ in range(length))


def make_uuid(data: Optional[str] = None) -> str:
    """
    Build a UUID-shaped string.
    If *data* (an IP address string) is provided the UUID is deterministic,
    otherwise it is random.  Mirrors utils.uuid.
    """
    if data:
        try:
            parts = [p for p in data.split(":") if p]
            chrs = parts[0] + parts[1].replace(".", "")
        except (IndexError, AttributeError):
            chrs = ""
        if chrs:
            return (
                _hex_seeded(8, chrs) + "-"
                + _hex_seeded(4, chrs) + "-4"
                + _hex_seeded(3, chrs) + "-a"
                + _hex_seeded(3, chrs) + "-"
                + _hex_seeded(12, chrs)
            )

    return str(_uuid_mod.uuid4())


# ---------------------------------------------------------------------------
# M3U8 / XMLTV merge helpers (mirrors utils.mergeM3U8 / utils.mergeXMLTV)
# ---------------------------------------------------------------------------

def merge_m3u8(playlists: dict[str, str], x_tvg_url: Optional[str] = None) -> str:
    """Concatenate regional M3U8 playlists into one."""
    if x_tvg_url:
        res = f'#EXTM3U x-tvg-url="{x_tvg_url}"\n\n'
    else:
        res = "#EXTM3U\n"

    for _region, playlist in playlists.items():
        for line in playlist.splitlines():
            if line.startswith("#EXTM3U"):
                continue
            res += line + "\n"
    return res


def merge_xmltv(epgs: dict[str, str]) -> Optional[str]:
    """Merge regional XMLTV XML strings into a single document."""
    root = None
    channels_all = []
    programmes_all = []

    for _region, xml_str in epgs.items():
        try:
            doc = ET.fromstring(xml_str)
        except ET.ParseError:
            continue
        if root is None:
            root = doc
        channels_all.extend(doc.findall("channel"))
        programmes_all.extend(doc.findall("programme"))

    if root is None:
        return None

    # Rebuild with merged children
    root.clear()
    root.attrib["source-info-name"] = "nobody,xmltv.net,nzxmltv.com"
    for ch in channels_all:
        _escape_icon_src(ch)
        root.append(ch)
    for pr in programmes_all:
        _escape_icon_src(pr)
        root.append(pr)

    ET.indent(root, space="    ")
    header = '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE tv SYSTEM "xmltv.dtv">\n'
    return header + ET.tostring(root, encoding="unicode")


def _escape_icon_src(element: ET.Element):
    for icon in element.iter("icon"):
        if "src" in icon.attrib:
            icon.attrib["src"] = escape_html(icon.attrib["src"])
