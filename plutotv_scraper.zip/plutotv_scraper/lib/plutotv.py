"""
Main orchestration — iterates over regions, fetches data, writes files.
Pure stdlib, fully synchronous.
"""

import logging
import os
from typing import Optional

from lib.api import PlutoAPI
from lib.ondemand import OnDemand
from lib.utils import merge_m3u8, merge_xmltv

log = logging.getLogger(__name__)


def process(config) -> None:
    mapping          = config.get_mapping()
    group            = config.get("group")
    regionalize      = config.get("regionalize")
    merge_all        = config.get("all")
    outdir           = config.get("outdir") or "."
    exclude_groups   = config.get("excludegroups") or None
    exclude_channels = config.get("excludechannels") or None
    x_tvg_url        = config.get("xtvgurl") or None
    vlcopts          = config.get("vlcopts")
    pipeopts         = config.get("pipeopts")
    do_ondemand      = config.get("ondemand")

    chno = config.get("chno")
    if chno is not None:
        chno = int(chno)

    regional_playlists: dict = {}
    regional_epgs:      dict = {}

    for region, xff in mapping.items():
        log.info("Processing region: %s  (xff=%s)", region, xff or "none")

        full_tvg_url: Optional[str] = None
        if x_tvg_url:
            full_tvg_url = x_tvg_url + (f"plutotv_{region}.xml" if x_tvg_url.endswith("/") else "")

        try:
            api = PlutoAPI()

            log.info("  boot …")
            boot_data = api.boot(xff or None, config.get("clientid"))

            log.info("  channels …")
            api.channels(xff or None)

            log.info("  categories …")
            api.categories(xff or None)

            log.info("  timelines …")
            api.timelines(xff or None)

            log.info("  generating M3U8 …")
            m3u8, num_channels = api.generate_m3u8(
                region, group, regionalize,
                exclude_groups, exclude_channels,
                chno, full_tvg_url, vlcopts, xff or None, pipeopts,
            )

            if chno is not None:
                chno += num_channels

            log.info("  generating XMLTV …")
            xmltv = api.generate_xmltv(region, regionalize)

            m3u8_path = os.path.join(outdir, f"plutotv_{region}.m3u8")
            xml_path  = os.path.join(outdir, f"plutotv_{region}.xml")
            with open(m3u8_path, "w", encoding="utf-8") as fh: fh.write(m3u8)
            with open(xml_path,  "w", encoding="utf-8") as fh: fh.write(xmltv)
            log.info("  wrote %s (%d channels) and %s", m3u8_path, num_channels, xml_path)

            regional_playlists[region] = m3u8
            regional_epgs[region]      = xmltv

            if do_ondemand:
                log.info("  on-demand …")
                vod = OnDemand()
                vod.fetch_categories(config, region, boot_data)

                od_m3u8, _ = vod.generate_m3u8(config, region, boot_data)
                if od_m3u8:
                    with open(os.path.join(outdir, f"plutotv_ondemand_{region}.m3u8"), "w", encoding="utf-8") as fh:
                        fh.write(od_m3u8)

                od_xml = vod.generate_xmltv(config, region)
                if od_xml:
                    with open(os.path.join(outdir, f"plutotv_ondemand_{region}.xml"), "w", encoding="utf-8") as fh:
                        fh.write(od_xml)

        except Exception as exc:
            log.error("Error processing region %s: %s", region, exc, exc_info=True)

    if merge_all and len(mapping) > 1:
        full_tvg_url = None
        if x_tvg_url:
            full_tvg_url = x_tvg_url + ("plutotv_all.xml" if x_tvg_url.endswith("/") else "")

        merged_m3u8 = merge_m3u8(regional_playlists, full_tvg_url)
        merged_xml  = merge_xmltv(regional_epgs)

        with open(os.path.join(outdir, "plutotv_all.m3u8"), "w", encoding="utf-8") as fh:
            fh.write(merged_m3u8)
        if merged_xml:
            with open(os.path.join(outdir, "plutotv_all.xml"), "w", encoding="utf-8") as fh:
                fh.write(merged_xml)
        log.info("Wrote merged plutotv_all.m3u8 and plutotv_all.xml")
