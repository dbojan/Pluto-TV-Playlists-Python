"""
Main orchestration — iterates over regions, fetches data, writes files.
Pure stdlib, fully synchronous.

JSON source mode (--json-source)
---------------------------------
Provide a public JSON file (produced by extract_public_data_from_json.py).
It is used as a fallback only: when the live Pluto TV API returns 0 channels
for a region, the scraper generates a stub playlist from the JSON channel data
instead of silently skipping that region.

If neither the live API nor the JSON source has data for a region, the region
is skipped with a warning.
"""

import base64
import json
import logging
import os
from datetime import datetime, timezone
from typing import Optional

from lib.api import (
	PlutoAPI,
	generate_m3u8_from_json,
	generate_xmltv_from_json,
	generate_m3u8_from_ids,
	generate_xmltv_from_ids,
)
from lib.ondemand import OnDemand
from lib.utils import merge_m3u8, merge_xmltv

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_json(path: str) -> Optional[dict]:
	try:
		with open(path, "r", encoding="utf-8") as fh:
			return json.load(fh)
	except FileNotFoundError:
		log.error("Cannot find JSON file: %s", path)
		return None
	except json.JSONDecodeError as exc:
		log.error("Cannot parse JSON file %s: %s", path, exc)
		return None


def _jwt_expiry(token: str) -> Optional[datetime]:
	"""Decode the JWT payload and return the exp field as a UTC datetime."""
	try:
		payload_b64 = token.split(".")[1]
		payload_b64 += "=" * (-len(payload_b64) % 4)
		payload = json.loads(base64.urlsafe_b64decode(payload_b64))
		return datetime.fromtimestamp(payload["exp"], tz=timezone.utc)
	except Exception:
		return None


def _expiry_comment(boot_data: dict) -> str:
	now	= datetime.now(timezone.utc)
	exp_dt = _jwt_expiry(boot_data.get("sessionToken", ""))
	fmt	= "%Y-%m-%d %H:%M:%S"
	return (
		f"\n#list updated: {now.strftime(fmt)} UTC"
		f"\n#jwt will expire: {(exp_dt.strftime(fmt) if exp_dt else 'unknown')} UTC\n"
	)


def _log_expiry(boot_data: dict, region: str) -> None:
	exp_dt = _jwt_expiry(boot_data.get("sessionToken", ""))
	if exp_dt:
		remaining = exp_dt - datetime.now(timezone.utc)
		h, rem = divmod(int(remaining.total_seconds()), 3600)
		m = rem // 60
		log.info("  JWT for %s expires %s UTC (in %dh %02dm)",
				 region, exp_dt.strftime("%Y-%m-%d %H:%M:%S"), h, m)
	else:
		log.warning("  Could not decode JWT expiry for %s", region)


# ---------------------------------------------------------------------------
# Main process
# ---------------------------------------------------------------------------

def process(config) -> None:
	mapping		  = config.get_mapping()
	group			= config.get("group")
	regionalize	  = config.get("regionalize")
	merge_all		= config.get("all")
	outdir		   = config.get("outdir") or "."
	exclude_groups   = config.get("excludegroups") or None
	exclude_channels = config.get("excludechannels") or None
	x_tvg_url		= config.get("xtvgurl") or None
	vlcopts		  = config.get("vlcopts")
	pipeopts		 = config.get("pipeopts")
	do_ondemand	  = config.get("ondemand")
	append_expiry	= config.get("appendexpiry")
	json_source_path = config.get("jsonsource") or None
	no_xml = config.get("noxml")

	# Load public JSON backup source (optional)
	json_source: Optional[dict] = _load_json(json_source_path) if json_source_path else None
	if json_source:
		n_regions = len(json_source.get("regions", {}))
		log.info("JSON source loaded: %s (%d region(s))", json_source_path, n_regions)

	chno = config.get("chno")
	if chno is not None:
		chno = int(chno)

	regional_playlists: dict = {}
	regional_epgs:	  dict = {}

	for region, xff in mapping.items():
		# Resolve XFF: config mapping first, then JSON source headers if present
		json_region = (json_source or {}).get("regions", {}).get(region)
		if not xff:
			xff = (json_region or {}).get("headers", {}).get("x-forwarded-for")

		log.info("Processing region: %s  (xff=%s)", region, xff or "none")

		full_tvg_url: Optional[str] = None
		if x_tvg_url:
			full_tvg_url = x_tvg_url + (
				f"plutotv_{region}.xml" if x_tvg_url.endswith("/") else ""
			)

		try:
			api = PlutoAPI()
			log.info("  boot …")
			boot_data = api.boot(xff or None, config.get("clientid"))
			_log_expiry(boot_data, region)

			m3u8:		 Optional[str] = None
			xmltv:		Optional[str] = None
			num_channels: int		   = 0
			used_live:	bool		  = False

			# ------------------------------------------------------------------
			# 1. Try live API first
			# ------------------------------------------------------------------
			log.info("  channels (live API) …")
			api.channels(xff or None)
			live_has_channels = bool(api.channel_list and api.channel_list.get("data"))

			if live_has_channels:
				log.info("  categories …")
				api.categories(xff or None)
				if no_xml:
					pass
				else:
					log.info("  timelines …")
					api.timelines(xff or None)

				log.info("  generating M3U8 from live API …")
				m3u8, num_channels = api.generate_m3u8(
					region, group, regionalize,
					exclude_groups, exclude_channels,
					chno, full_tvg_url, vlcopts, xff or None, pipeopts,
				)
				if no_xml:
					pass
				else:
					log.info("  generating XMLTV from live API …")
					xmltv = api.generate_xmltv(region, regionalize)
					
				used_live = True
				log.info("  live API: %d channels", num_channels)

			# ------------------------------------------------------------------
			# 2. Live returned nothing — fall back to JSON source
			# ------------------------------------------------------------------
			if num_channels == 0:
				if json_region and json_region.get("channels"):
					log.info(
						"  live API empty — falling back to JSON source for %s "
						"(%d channels)",
						region, len(json_region["channels"]),
					)
					m3u8, num_channels = generate_m3u8_from_json(
						json_region, region, boot_data,
						group, regionalize,
						exclude_groups, exclude_channels,
						chno, full_tvg_url, vlcopts, xff or None, pipeopts,
					)
					if no_xml:
						pass
					else:
						xmltv = generate_xmltv_from_json(json_region, region, regionalize)
					log.info("  JSON source: %d channels", num_channels)

				else:
					log.warning(
						"  0 channels from all sources for %s — skipping", region
					)
					continue

			# ------------------------------------------------------------------
			# Append expiry comment if requested
			# ------------------------------------------------------------------
			if append_expiry and m3u8:
				m3u8 = m3u8.rstrip("\n") + _expiry_comment(boot_data)

			if chno is not None:
				chno += num_channels

			# Write files
			m3u8_path = os.path.join(outdir, f"plutotv_{region}.m3u8")
			xml_path  = os.path.join(outdir, f"plutotv_{region}.xml")
			with open(m3u8_path, "w", encoding="utf-8") as fh:
				fh.write(m3u8)
			if xmltv:#onlly if xml exists, if --no-xml was used, there is no xml, so skip it.
				with open(xml_path, "w", encoding="utf-8") as fh:
					fh.write(xmltv)
				log.info("  wrote %s (%d channels) and %s", m3u8_path, num_channels, xml_path)
			else:
				log.info("  wrote %s (%d channels)", m3u8_path, num_channels)

			regional_playlists[region] = m3u8
			regional_epgs[region]	  = xmltv

			# On-demand only makes sense from live API data
			if do_ondemand and used_live:
				log.info("  on-demand …")
				vod = OnDemand()
				vod.fetch_categories(config, region, boot_data)
				od_m3u8, _ = vod.generate_m3u8(config, region, boot_data)
				if od_m3u8:
					with open(
						os.path.join(outdir, f"plutotv_ondemand_{region}.m3u8"),
						"w", encoding="utf-8",
					) as fh:
						fh.write(od_m3u8)
				od_xml = vod.generate_xmltv(config, region)
				if od_xml:
					with open(
						os.path.join(outdir, f"plutotv_ondemand_{region}.xml"),
						"w", encoding="utf-8",
					) as fh:
						fh.write(od_xml)

		except Exception as exc:
			log.error("Error processing region %s: %s", region, exc, exc_info=True)

	# ------------------------------------------------------------------
	# Merge all regions
	# ------------------------------------------------------------------
	if merge_all and len(mapping) > 1:
		merge_xml_message=""
		full_tvg_url = None
		if x_tvg_url:
			full_tvg_url = x_tvg_url + ("plutotv_all.xml" if x_tvg_url.endswith("/") else "")
		merged_m3u8 = merge_m3u8(regional_playlists, full_tvg_url)
		with open(os.path.join(outdir, "plutotv_all.m3u8"), "w", encoding="utf-8") as fh:
			fh.write(merged_m3u8)
		if no_xml:
			pass
		else:
			merged_xml  = merge_xmltv(regional_epgs)
			if merged_xml:
				with open(os.path.join(outdir, "plutotv_all.xml"), "w", encoding="utf-8") as fh:
					fh.write(merged_xml)
				merge_xml_message= " and plutotv_all.xml"
		log.info("Wrote merged plutotv_all.m3u8" + merge_xml_message)
