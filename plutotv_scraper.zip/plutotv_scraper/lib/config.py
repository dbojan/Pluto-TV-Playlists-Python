"""
Configuration loader — reads config.json and merges CLI arguments on top.
Mirrors lib/config.js from the original JS project.
"""

import json
import logging
import os
from typing import Any

log = logging.getLogger(__name__)

DEFAULTS: dict[str, Any] = {
    "outdir":          ".",
    "clientid":        "00000000-0000-0000-0000-000000000000",
    "mapping":         {"us": "45.50.96.71"},
    "all":             False,
    "group":           "genre",
    "regionalize":     False,
    "excludegroups":   False,
    "excludechannels": False,
    "chno":            None,
    "port":            None,
    "uniqueclientid":  False,
    "randomclientid":  False,
    "refresh":         0,
    "xtvgurl":         False,
    "ondemand":        False,
    "vlcopts":         False,
    "pipeopts":        False,
}

# Map CLI dest names (lowercase, underscores) → canonical config keys (lowercase)
_CLI_KEY_MAP = {
    "clientid":        "clientid",
    "exclude_groups":  "excludegroups",
    "exclude_channels":"excludechannels",
    "unique_clientid": "uniqueclientid",
    "random_clientid": "randomclientid",
    "x_tvg_url":       "xtvgurl",
}


class Config:
    def __init__(self, args):
        self._args = args
        self._cfg: dict[str, Any] = {}

    def load(self):
        configfile = getattr(self._args, "config", None) or "config.json"
        file_cfg: dict = {}
        try:
            with open(configfile, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
            # Normalise file keys to lowercase (clientID → clientid, etc.)
            file_cfg = {k.lower(): v for k, v in raw.items()}
        except FileNotFoundError:
            if configfile != "config.json":
                log.error("Config file not found: %s", configfile)
        except json.JSONDecodeError as exc:
            log.error("Error parsing config file %s: %s", configfile, exc)

        for key in DEFAULTS:
            # 1. CLI argument (highest priority)
            cli_attr = next(
                (a for a, k in _CLI_KEY_MAP.items() if k == key),
                key,
            )
            cli_val = getattr(self._args, cli_attr, None)
            # argparse stores False for store_true when not supplied; treat None == not set
            if cli_val is None or cli_val is False and key not in (
                "all", "regionalize", "uniqueclientid", "randomclientid",
                "ondemand", "vlcopts", "pipeopts",
            ):
                cli_val = None

            # 2. Config file
            file_val = file_cfg.get(key)

            # 3. Default
            self._cfg[key] = cli_val if cli_val is not None else (
                file_val if file_val is not None else DEFAULTS[key]
            )

        # Ensure outdir exists
        outdir = self._cfg.get("outdir", ".")
        os.makedirs(outdir, exist_ok=True)

    def get(self, key: str) -> Any:
        return self._cfg.get(key.lower())

    def get_mapping(self) -> dict[str, str]:
        """Return region→IP mapping, honouring --mapping CLI override."""
        mapping_arg = getattr(self._args, "mapping", None)
        if mapping_arg:
            parts = mapping_arg.split(",", 1)
            region = parts[0].strip()
            ip     = parts[1].strip() if len(parts) > 1 else ""
            return {region: ip}
        return self.get("mapping") or {}
