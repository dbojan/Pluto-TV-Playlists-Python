https://github.com/NasiLemakk/Pluto-TV-Playlists

Code	Country	Example IP
us	United States	45.50.96.71
ca	Canada	23.227.38.65
uk	United Kingdom	51.89.255.67
de	Germany	91.107.201.140
at	Austria	185.229.226.1
ch	Switzerland	195.65.200.1
fr	France	51.210.0.1
es	Spain	82.98.134.10
it	Italy	79.137.44.85
no	Norway	91.235.80.1
se	Sweden	185.152.64.1
dk	Denmark	185.183.104.1
fi	Finland	91.153.148.1
au	Australia	1.128.0.1
br	Brazil	177.75.0.1
mx	Mexico	187.174.0.1
ar	Argentina	181.30.0.1
cl	Chile	190.20.0.1
co	Colombia	190.0.0.1
pe	Peru	186.33.0.1

removed
    "de": "91.107.201.140",
    "fr": "51.210.0.1",
    "es": "82.98.134.10",
    "it": "79.137.44.85"

already there
"ca", "uk", "us", 

added:
"no", "se", "dk" 
    "no": "91.235.80.1",
    "se": "185.152.64.1",
    "dk": "185.183.104.1",

A few important caveats:

The IP is the key — the code sends it as X-Forwarded-For to trick Pluto's geo-detection. Any real IP from that country works; the ones above are just known-good examples.
gb not uk — your current config uses "uk" as the key, but the region code Pluto returns is GB. This doesn't break anything (the key is just a label you choose), but worth knowing.
Nordic countries (no, se, dk, fi) are confirmed available — Pluto entered that market via a NENT Group partnership.
Latin America is available but the channel catalogue is much smaller than US/CA/EU. Countries like ar, cl, co, pe work but may return limited results.
Australia is available via Network 10 partnership, though the catalogue is different from the US.

To add them all, just expand your config.json mapping section with the codes and IPs above.
