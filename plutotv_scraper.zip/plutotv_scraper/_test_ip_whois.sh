i="181.30.0.1"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="89.144.233.144"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="200.221.2.45"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="23.227.38.65"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="200.28.232.1"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="186.28.0.1"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="176.21.34.141"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="51.210.0.1"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="91.107.201.140"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="95.110.150.1"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="201.124.0.1"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="109.247.0.1"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="190.116.0.1"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="82.159.200.1"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="194.242.108.1"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="62.2.0.1"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="51.89.255.67"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1
i="45.50.96.71"; whois "$i" |grep -i country ; echo -e "$i\n\n" ; sleep 1


#channels in june: at de; ar pe co; ?
#ar 188
#at 200
#br 171
#ca 211
#cl 187
#co 188
#dk 239
#fr 133
#de 200
#it 121
#mx 191
#no 186
#pe 188
#es 144
#se 205
#ch 199
#gb 193
#us 412

