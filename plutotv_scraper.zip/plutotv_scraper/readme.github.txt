mostly english speaking: "ca", "uk", "us", "no", "se", "dk".

you can edit config.json, to change countries.

removed from config.json, since they do not work:
"au": "1.120.0.1",
"fi": "193.166.1.1",
"nz": "202.49.0.1",

