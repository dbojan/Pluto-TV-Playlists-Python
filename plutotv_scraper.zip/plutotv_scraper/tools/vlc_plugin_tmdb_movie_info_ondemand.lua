
--tmdb movie info vlc plugin
--put this in /home/b/.local/share/vlc/lua/extensions/, then activate from vlc menu
--2026-06-04-1

function descriptor()
    return {
        title = "TMDb IPTV Lookup (Startup Check)",
        version = "2.3",
        author = "ChatGPT",
        capabilities = {}
    }
end

--------------------------------------------------
-- CONFIG
--------------------------------------------------

local API_KEY = "0b9ef2c347bb1b0f80a46ca53d8c23b2"

--------------------------------------------------
-- STATE
--------------------------------------------------

local dlg
local output_label
local meta_label
local log_label

local log_text = ""

local cache = {}

local timer = nil

local startup_title = nil
local check_phase = 0
local check_time = 0

--------------------------------------------------
-- LIFECYCLE
--------------------------------------------------

function activate()
    create_ui()

    local item = vlc.input.item()
    if not item then
        log("No media loaded")
        return
    end

    startup_title = get_title()
    log("startup title: " .. tostring(startup_title))

    fetch_movie_info()

    log("waiting 5 seconds to check for title change")

    check_phase = 1
    check_time = os.time()

    timer = vlc.misc.timer()
    timer.callback = startup_check
    timer:start(1000000, true)
end

function deactivate()
    if timer then
        timer:stop()
        timer = nil
    end
end

function close()
    vlc.deactivate()
end

--------------------------------------------------
-- UI
--------------------------------------------------

function create_ui()
    dlg = vlc.dialog("TMDb IPTV Lookup")

    dlg:add_button("Get Movie Info", fetch_movie_info, 1, 1, 1, 1)
    dlg:add_button("Show Metadata", show_metadata, 2, 1, 1, 1)

    dlg:add_label("Output:", 1, 2, 2, 1)
    output_label = dlg:add_label("", 1, 3, 2, 2)

    dlg:add_label("Metadata:", 1, 5, 2, 1)
    meta_label = dlg:add_label("", 1, 6, 2, 3)

    dlg:add_label("Log:", 1, 9, 2, 1)
    log_label = dlg:add_label("", 1, 10, 2, 5)

    log("UI loaded")
end

--------------------------------------------------
-- LOGGING
--------------------------------------------------

function log(msg)
    log_text = log_text .. tostring(msg) .. "<br>"
    if log_label then log_label:set_text(log_text) end
    vlc.msg.info(msg)
end

function clear()
    log_text = ""
end

--------------------------------------------------
-- HELPERS
--------------------------------------------------

function get_item()
    return vlc.input.item()
end

function get_uri()
    local item = get_item()
    if not item then return nil end
    return item:uri()
end

function get_title()
    local item = get_item()
    if not item then return nil end

    local metas = item:metas()
    local title = (metas and metas["title"] ~= "" and metas["title"]) or item:name()

    return title
end

--------------------------------------------------
-- STARTUP CHECK
--------------------------------------------------

function startup_check()
    if check_phase ~= 1 then return end

    local now = os.time()

    if (now - check_time) < 5 then
        return
    end

    check_phase = 2

    log("detecting title")

    local current_title = get_title()

    if current_title ~= startup_title then
        log("new title detected: " .. tostring(current_title))
        startup_title = current_title
        fetch_movie_info()
    else
        log("no title change")
    end
end

--------------------------------------------------
-- TMDB FETCH
--------------------------------------------------

function fetch_movie_info()

    clear()

    local uri = get_uri()
    local title = get_title()

    if not uri or not title then
        log("No media loaded")
        return
    end

    log("TITLE: " .. title)

    --------------------------------------------------
    -- CACHE CHECK
    --------------------------------------------------

    if cache[uri] then
        log("CACHE HIT")

        local c = cache[uri]

        output_label:set_text(
            "TITLE: " .. (c.title or "N/A") ..
            "<br>DATE: " .. (c.date or "N/A") ..
            "<br>RATING: " .. (c.rating or "N/A") .. "/10" ..
            "<br>VOTES: " .. (c.votes or "N/A") ..
            "<br>CAST: " .. (c.cast or "N/A")
        )

        meta_label:set_text(
            "OVERVIEW:<br>" .. wrap_text(c.overview, 100)
        )

        return
    end

    --------------------------------------------------
    -- SEARCH TMDB
    --------------------------------------------------

    local query = title:gsub(" ", "+")

    local url =
        "https://api.themoviedb.org/3/search/movie?api_key=" ..
        API_KEY .. "&query=" .. query

    local stream = vlc.stream(url)
    local data = stream and stream:read(200000)

    if not data then
        log("Search failed")
        return
    end

    local id = data:match('"id":(%d+)')
    if not id then
        log("No movie found")
        return
    end

    --------------------------------------------------
    -- MOVIE DETAILS
    --------------------------------------------------

    local url2 =
        "https://api.themoviedb.org/3/movie/" ..
        id .. "?api_key=" .. API_KEY

    local stream2 = vlc.stream(url2)
    local data2 = stream2 and stream2:read(200000)

    if not data2 then
        log("Details failed")
        return
    end

    local movie = data2:match('"title":"(.-)"')
    local date = data2:match('"release_date":"(.-)"')
    local overview = data2:match('"overview":"(.-)"')

    local rating = data2:match('"vote_average":([%d%.]+)')
    local votes = data2:match('"vote_count":(%d+)')

    if overview then
        overview = overview:gsub("\\n", " "):gsub("\\\"", "\"")
    end

    --------------------------------------------------
    -- CAST / ACTORS
    --------------------------------------------------

    local url3 =
        "https://api.themoviedb.org/3/movie/" ..
        id .. "/credits?api_key=" .. API_KEY

    local stream3 = vlc.stream(url3)
    local data3 = stream3 and stream3:read(200000)

    local cast_text = "N/A"

    if data3 then
        local cast_list = {}

        for block in data3:gmatch('"cast":%[(.-)%]') do
            for name in block:gmatch('"name":"(.-)"') do
                table.insert(cast_list, name)
                if #cast_list >= 5 then break end
            end
        end

        if #cast_list > 0 then
            cast_text = table.concat(cast_list, ", ")
        end
    end

    --------------------------------------------------
    -- OUTPUT
    --------------------------------------------------

    output_label:set_text(
        "TITLE: " .. (movie or "N/A") ..
        "<br>DATE: " .. (date or "N/A") ..
        "<br>RATING: " .. (rating or "N/A") .. "/10" ..
        "<br>VOTES: " .. (votes or "N/A") ..
        "<br>CAST: " .. cast_text
    )

    meta_label:set_text(
        "OVERVIEW:<br>" .. wrap_text(overview, 100)
    )

    --------------------------------------------------
    -- CACHE STORE
    --------------------------------------------------

    cache[uri] = {
        title = movie,
        date = date,
        overview = overview,
        rating = rating,
        votes = votes,
        cast = cast_text
    }

    log("DONE + cached")
end

--------------------------------------------------
-- TEXT WRAP
--------------------------------------------------

function wrap_text(text, width)
    if not text then return "" end

    local result = ""
    local line = ""

    for word in tostring(text):gmatch("%S+") do
        if #line + #word + 1 > width then
            result = result .. line .. "<br>"
            line = word
        else
            if line == "" then line = word else line = line .. " " .. word end
        end
    end

    if line ~= "" then result = result .. line end

    return result
end

--------------------------------------------------
-- METADATA VIEW
--------------------------------------------------

function show_metadata()

    clear()

    local item = vlc.input.item()
    if not item then return end

    log("ITEM: " .. item:name())

    local metas = item:metas()
    if not metas then
        log("No metadata")
        return
    end

    for k, v in pairs(metas) do
        log(k .. " = " .. tostring(v))
    end
end
