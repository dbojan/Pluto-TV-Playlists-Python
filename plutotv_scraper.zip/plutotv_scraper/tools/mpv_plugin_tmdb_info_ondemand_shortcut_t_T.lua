-- tmdb_info.lua  2026-06-04
-- mpv Lua script — TMDb movie info on keypress
-- INSTALL: cp tmdb_info.lua ~/.config/mpv/scripts/
-- KEYS: t = lookup,  T = clear cache + lookup

local API_KEY      = "0b9ef2c347bb1b0f80a46ca53d8c23b2"
local OSD_DURATION = 12
local cache        = {}

local function wrap(s, w)
    if not s or s=="" then return "" end
    local out, cur = {}, ""
    for word in s:gmatch("%S+") do
        if cur=="" then cur=word
        elseif #cur+1+#word<=w then cur=cur.." "..word
        else out[#out+1]=cur; cur=word end
    end
    if cur~="" then out[#out+1]=cur end
    return table.concat(out, "\n")
end

local function fetch(url)
    local cmd = {"curl", "-s", "--max-time", "10", url}
    local r = mp.command_native({name="subprocess", args=cmd, capture_stdout=true})
    return r and r.stdout or nil
end

local function lookup()
    local title = mp.get_property("media-title") or ""
    if title=="" then mp.osd_message("TMDb: no title", OSD_DURATION); return end

    if cache[title] then
        mp.osd_message(cache[title], OSD_DURATION); return
    end

    mp.osd_message("TMDb: searching for\n"..title.."...", 3)

    -- search
    local q = title:gsub("([^%w%-_ ])", function(c)
        return string.format("%%%02X", string.byte(c))
    end):gsub(" ", "+")
    local data = fetch("https://api.themoviedb.org/3/search/movie?api_key="..API_KEY.."&query="..q)
    if not data then mp.osd_message("TMDb: search failed", OSD_DURATION); return end

    local id = data:match('"id":(%d+)')
    if not id then mp.osd_message("TMDb: no match for\n"..title, OSD_DURATION); return end

    -- details
    local d = fetch("https://api.themoviedb.org/3/movie/"..id.."?api_key="..API_KEY)
    if not d then mp.osd_message("TMDb: details failed", OSD_DURATION); return end

    local movie    = d:match('"title":"(.-)"')         or "N/A"
    local date     = d:match('"release_date":"(.-)"')  or "N/A"
    local rating   = d:match('"vote_average":([%d%.]+)')or "N/A"
    local votes    = d:match('"vote_count":(%d+)')      or "N/A"
    local overview = d:match('"overview":"(.-)"')       or ""
    overview = overview:gsub("\\n"," "):gsub('\\"','"')

    -- cast
    local cast_str = ""
    local c = fetch("https://api.themoviedb.org/3/movie/"..id.."/credits?api_key="..API_KEY)
    if c then
        local cast = {}
        for blk in c:gmatch('"cast":%[(.-)%]') do
            for name in blk:gmatch('"name":"(.-)"') do
                cast[#cast+1]=name; if #cast>=5 then break end
            end
        end
        if #cast>0 then cast_str = table.concat(cast,", ") end
    end

    local msg = movie.."\n"
              ..date.."  |  "..rating.."/10  ("..votes.." votes)\n"
              ..(cast_str~="" and cast_str.."\n" or "")
              .."\n"..wrap(overview, 60)

    cache[title] = msg
    mp.osd_message(msg, OSD_DURATION)
end

mp.add_key_binding("t", "tmdb_lookup", lookup)
mp.add_key_binding("T", "tmdb_reload", function() cache={}; lookup() end)
mp.msg.info("tmdb_info loaded — t=lookup  T=reload+lookup")
