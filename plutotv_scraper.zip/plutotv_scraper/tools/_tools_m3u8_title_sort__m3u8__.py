#python ./_tools_m3u8_title_sort__m3u8__.py --skip-url --all --skip-sorted --replace --no-backup


import sys
import os
import argparse
import glob
import shutil

def sort_m3u8_by_title(input_file, skip_duplicate_url=False, output_file=None, prefix_output=False, quiet=False, replace=False, no_backup=False):
    if not quiet:
        print(f"Processing: {input_file}")
    
    # Read original file
    with open(input_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    header = []
    tracks = []
    current_extinf = None
    pending_comments = []
    seen_urls = set()
    duplicates_skipped = 0
    
    i = 0
    while i < len(lines):
        line = lines[i].rstrip('\n')
        
        if not line.strip():
            i += 1
            continue
        
        if not tracks and (line.startswith('#EXTM3U') or line.startswith('#EXT-X-VERSION')):
            header.append(line)
            i += 1
            continue
        
        if line.startswith('#EXTINF'):
            current_extinf = line
            i += 1
            continue
        
        if line and not line.startswith('#'):
            if skip_duplicate_url and line in seen_urls:
                duplicates_skipped += 1
                current_extinf = None
                pending_comments = []
                i += 1
                continue
            
            if skip_duplicate_url:
                seen_urls.add(line)
            
            title = ""
            if current_extinf and ',' in current_extinf:
                title = current_extinf.rsplit(',', 1)[-1].strip()
            else:
                title = line.split('/')[-1]
            
            tracks.append((title, current_extinf, line, pending_comments.copy()))
            current_extinf = None
            pending_comments = []
            i += 1
            continue
        
        if line.startswith('#'):
            pending_comments.append(line)
            i += 1
            continue
        
        title = line.split('/')[-1]
        if skip_duplicate_url and line in seen_urls:
            duplicates_skipped += 1
        else:
            if skip_duplicate_url:
                seen_urls.add(line)
            tracks.append((title, None, line, pending_comments.copy()))
        pending_comments = []
        i += 1
    
    if len(tracks) == 0:
        if not quiet:
            print(f"  ⚠️ WARNING: No tracks found in {input_file}")
        return None
    
    tracks.sort(key=lambda x: x[0].lower())

    # Determine output filename
    if replace:
        # When replacing, write to a temp file first, then replace original
        output_file = input_file + ".tmp"
        final_file = input_file
    elif output_file is None:
        base, ext = os.path.splitext(input_file)
        if prefix_output:
            output_file = os.path.join(os.path.dirname(input_file), f"sorted-{os.path.basename(input_file)}")
        else:
            output_file = f"{base}-sorted{ext}"
        final_file = output_file
    else:
        final_file = output_file
        output_file = output_file
    
    if not quiet:
        if replace:
            print(f"  Will replace original file: {input_file}")
            if not no_backup:
                print(f"  Backup will be saved as: {input_file}.backup")
            else:
                print(f"  No backup will be created (--no-backup)")
        else:
            print(f"  Writing to file: {output_file}")
    
    # Write to temp file or directly to output
    write_target = output_file if not replace else input_file + ".tmp"
    
    with open(write_target, 'w', encoding='utf-8') as f:
        for h in header:
            f.write(h + '\n')
        
        for title, extinf, url, comments in tracks:
            for comment in comments:
                f.write(comment + '\n')
            if extinf:
                f.write(extinf + '\n')
            f.write(url + '\n')
    
    # If replace mode, replace the original file
    if replace:
        if not no_backup:
            # Create backup only if file doesn't already have .backup
            backup_file = input_file + ".backup"
            if os.path.exists(backup_file):
                if not quiet:
                    print(f"  ⚠️ Backup already exists, skipping backup creation")
            else:
                shutil.move(input_file, backup_file)
                if not quiet:
                    print(f"  ✓ Backup saved as {backup_file}")
        else:
            # No backup, just remove original
            os.remove(input_file)
            if not quiet:
                print(f"  ✓ Original file removed (no backup)")
        
        # Move temp file to original location
        shutil.move(write_target, input_file)
        
        if not quiet:
            print(f"  ✓ Replaced original file")
        output_file = input_file
    
    if not quiet and not replace:
        file_size = os.path.getsize(output_file)
        print(f"  ✓ Saved {file_size} bytes ({len(tracks)} tracks, {duplicates_skipped} duplicates skipped)")
    elif not quiet and replace:
        file_size = os.path.getsize(input_file)
        print(f"  ✓ Replaced {file_size} bytes ({len(tracks)} tracks, {duplicates_skipped} duplicates skipped)")
    
    return output_file

def process_all_m3u_files(skip_duplicate_url=False, prefix_output=False, quiet=False, skip_sorted=False, replace=False, no_backup=False):
    """Process all .m3u and .m3u8 files in current directory"""
    m3u_files = glob.glob("*.m3u") + glob.glob("*.m3u8")
    
    if not quiet:
        print(f"\nFound {len(m3u_files)} total .m3u/.m3u8 files in {os.getcwd()}")
    
    # Filter out files based on skip_sorted flag
    filtered_files = []
    skipped_files = []
    
    for f in m3u_files:
        should_skip = False
        reason = ""
        
        # Check if file should be skipped
        if skip_sorted and 'sorted' in f.lower():
            should_skip = True
            reason = "contains 'sorted' (--skip-sorted)"
        elif not skip_sorted and not replace:
            # Original behavior: skip only exact prefix/suffix
            base, ext = os.path.splitext(f)
            if base.startswith("sorted-") or base.endswith("-sorted"):
                should_skip = True
                reason = "already sorted (exact match)"
        
        if should_skip:
            skipped_files.append((f, reason))
            if not quiet:
                print(f"  ⏭️ SKIPPING ({reason}): {f}")
        else:
            filtered_files.append(f)
    
    if not quiet and skipped_files:
        print(f"\nSkipped {len(skipped_files)} file(s)")
    
    m3u_files = filtered_files
    
    if not m3u_files:
        if not quiet:
            print(f"\nNo .m3u or .m3u8 files to process")
        return []
    
    if not quiet:
        print(f"\n{'='*60}")
        if replace:
            print(f"Processing {len(m3u_files)} file(s) (REPLACE MODE - original files will be overwritten):")
            if no_backup:
                print(f"⚠️  NO BACKUP mode - original files will be permanently overwritten!")
        else:
            print(f"Processing {len(m3u_files)} file(s):")
        print(f"{'='*60}")
    
    if replace and not quiet and not no_backup:
        print("\n⚠️  WARNING: Replace mode is active! Original files will be overwritten.")
        print("   Backup files (.backup) will be created for safety.\n")
    elif replace and not quiet and no_backup:
        print("\n⚠️⚠️⚠️  DESTRUCTIVE MODE: --no-backup is active!")
        print("   Original files will be permanently overwritten WITHOUT backup!")
        print("   This action cannot be undone!\n")
    
    processed_files = []
    failed_files = []
    
    for m3u_file in m3u_files:
        if not quiet:
            print(f"\n--- Processing: {m3u_file} ---")
        try:
            output = sort_m3u8_by_title(
                m3u_file,
                skip_duplicate_url=skip_duplicate_url,
                output_file=None,
                prefix_output=prefix_output,
                quiet=quiet,
                replace=replace,
                no_backup=no_backup
            )
            if output:
                processed_files.append(output)
            else:
                failed_files.append(m3u_file)
        except Exception as e:
            if not quiet:
                print(f"  ✗ FAILED: {e}")
            failed_files.append(m3u_file)
    
    if not quiet:
        print(f"\n{'='*60}")
        print(f"RESULTS:")
        print(f"{'='*60}")
        print(f"✓ Successfully processed: {len(processed_files)} files")
        if failed_files:
            print(f"✗ Failed: {len(failed_files)} files")
            for f in failed_files:
                print(f"  - {f}")
        if skipped_files:
            print(f"⏭️ Skipped: {len(skipped_files)} files")
            if not quiet:
                for f, reason in skipped_files:
                    print(f"  - {f} ({reason})")
        
        if processed_files and not replace:
            print(f"\nOutput files created:")
            for f in processed_files:
                print(f"  - {f}")
        elif processed_files and replace:
            print(f"\nOriginal files replaced:")
            for f in processed_files:
                print(f"  - {f}")
            if not no_backup:
                print(f"\n⚠️  Backup files (.backup) have been saved in case you need to restore.")
            else:
                print(f"\n⚠️⚠️⚠️  No backups were created! Original files are permanently replaced.")
    
    return processed_files

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Sort M3U8 playlist by title')
    parser.add_argument('input_file', nargs='?', help='Input M3U8 playlist file (optional if using --all)')
    parser.add_argument('--skip-url', action='store_true', 
                        help='Skip duplicate URLs in output')
    parser.add_argument('--prefix', action='store_true',
                        help='Add "sorted-" prefix to output filename instead of "-sorted" suffix')
    parser.add_argument('--output', '-o', 
                        help='Custom output file path (overrides --prefix)')
    parser.add_argument('--all', action='store_true',
                        help='Process all .m3u and .m3u8 files in current directory')
    parser.add_argument('--quiet', '-q', action='store_true',
                        help='Suppress all screen output (silent mode)')
    parser.add_argument('--skip-sorted', action='store_true',
                        help='Skip any file that contains "sorted" anywhere in the filename')
    parser.add_argument('--replace', action='store_true',
                        help='Replace original file with sorted version')
    parser.add_argument('--no-backup', action='store_true',
                        help='When used with --replace, do not create .backup files (DESTRUCTIVE)')
    
    args = parser.parse_args()
    
    # Warning for incompatible options
    if args.replace and args.prefix:
        print("Warning: --replace ignores --prefix (file will keep original name)")
    if args.replace and args.output:
        print("Warning: --replace ignores --output (file will keep original name)")
    if args.no_backup and not args.replace:
        print("Warning: --no-backup only works with --replace, ignoring...")
    
    if args.all:
        if args.input_file and not args.quiet:
            print("Warning: --all flag is set. Ignoring input_file argument.")
        if args.output and not args.quiet and not args.replace:
            print("Warning: --output flag is ignored when using --all")
        process_all_m3u_files(
            skip_duplicate_url=args.skip_url,
            prefix_output=args.prefix,
            quiet=args.quiet,
            skip_sorted=args.skip_sorted,
            replace=args.replace,
            no_backup=args.no_backup if args.replace else False
        )
    else:
        if not args.input_file:
            parser.error("input_file is required when not using --all")
        
        if not os.path.exists(args.input_file):
            print(f"Error: Input file '{args.input_file}' not found")
            sys.exit(1)
        
        sort_m3u8_by_title(
            args.input_file, 
            skip_duplicate_url=args.skip_url,
            output_file=args.output,
            prefix_output=args.prefix,
            quiet=args.quiet,
            replace=args.replace,
            no_backup=args.no_backup if args.replace else False
        )
