-- plutotv_epg.lua  v2.4  2026-06-04
-- mpv Lua script — PlutoTV EPG/VOD info on keypress
--
-- INSTALL:  cp plutotv_epg.lua ~/.config/mpv/scripts/
-- KEYS:     e = show EPG,  E = reload XML + show

local OSD_DURATION = 8
--local XML_DIR = "/home/b/data/p_iptv-free-balkan/plutotv_scraper/current/output"

local cache = {}

local function norm(s)
    if not s then return "" end
    return s:lower():gsub("pluto%s*tv%s*",""):gsub("[^%a%d]","")
end

local function decode(s)
    if not s then return "" end
    return s:gsub("&amp;","&"):gsub("&lt;","<"):gsub("&gt;",">"):gsub("&quot;",'"')
             :gsub("&#(%d+);", function(n) return string.char(tonumber(n)) end)
end

local function wrap(s, w)
    if not s or s == "" then return "" end
    local out, cur = {}, ""
    for word in s:gmatch("%S+") do
        if cur == "" then cur = word
        elseif #cur + 1 + #word <= w then cur = cur.." "..word
        else out[#out+1] = cur; cur = word end
    end
    if cur ~= "" then out[#out+1] = cur end
    return table.concat(out, "\n")
end

local function xmltv_epoch(s)
    if not s or #s < 12 then return 0 end
    return os.time({ year=tonumber(s:sub(1,4)), month=tonumber(s:sub(5,6)),
        day=tonumber(s:sub(7,8)), hour=tonumber(s:sub(9,10)),
        min=tonumber(s:sub(11,12)), sec=0, isdst=false })
end

local function fmt_epoch(s)
    local e = xmltv_epoch(s)
    return e > 0 and os.date("%H:%M", e) or "?"
end

local function parse_xmltv(path)
    local f = io.open(path, "r")
    if not f then return nil end
    local raw = f:read("*a"); f:close()
    if not raw or raw == "" then return nil end
    local progs, names, id2norm = {}, {}, {}
    for blk in raw:gmatch("<channel%s(.-)%s*</channel>") do
        local id   = blk:match('id="([^"]+)"')
        local name = blk:match("<display%-name[^>]*>([^<]+)</display%-name>")
        if id and name then
            name = decode(name:match("^%s*(.-)%s*$"))
            local n = norm(name)
            id2norm[id] = n; names[n] = name; progs[n] = progs[n] or {}
        end
    end
    for blk in raw:gmatch("<programme%s(.-)%s*</programme>") do
        local n = id2norm[ blk:match('channel="([^"]+)"') or "" ]
        if n then
            table.insert(progs[n], {
                title = decode((blk:match("<title[^>]*>([^<]+)</title>") or ""):match("^%s*(.-)%s*$")),
                desc  = decode((blk:match("<desc[^>]*>([^<]*)</desc>")  or ""):match("^%s*(.-)%s*$")),
                start = blk:match('start="([^"]+)"') or "",
                stop  = blk:match('stop="([^"]+)"')  or "",
            })
        end
    end
    return { progs=progs, names=names }
end

local function find_prog(data, stream_name)
    local n = norm(stream_name)
    if n == "" then return nil, nil, nil end
    local key = data.progs[n] and n
    if not key then
        local best, best_len = nil, 0
        for k in pairs(data.progs) do
            if #k >= 6 and #k / #n >= 0.5 then
                if k:find(n,1,true) or n:find(k,1,true) then
                    if #k > best_len then best, best_len = k, #k end
                end
            end
        end
        key = best
    end
    if not key then return nil, nil, nil end
    local list = data.progs[key]
    local now = os.time()
    for _, p in ipairs(list) do
        local s, e = xmltv_epoch(p.start), xmltv_epoch(p.stop)
        if s > 0 and e > 0 and now >= s and now < e then
            return p, data.names[key], "now"
        end
    end
    for _, p in ipairs(list) do
        if p.title ~= "" then return p, data.names[key], "listed" end
    end
    return list[1], data.names[key], "listed"
end

local function get_xml_path()
	--get full path to .m3u8 file, replace .m3u8 with .xml
    local path = mp.get_property("playlist-path") or ""
    if path == "" then return nil end

    return path:gsub(".m3u8", ".xml")
end

local function build_msg(stream_name)
    local xml = get_xml_path()


    if not xml then
        return "No XML path resolved"
    end

    local data = parse_xmltv(xml)

    if not data then
        return "Cannot open XML: " .. xml
    end

    local p, raw, timing = find_prog(data, stream_name)

    if not p then
        return "No EPG match for: "..stream_name.." in "..xml
    end

    local time = ""
    --if timing == "now" then
        --time = fmt_epoch(p.start) .. " - " .. fmt_epoch(p.stop) .. "\n"
    --end
    
	if timing == "now" then
		local start_str = fmt_epoch(p.start)
		local stop_str = fmt_epoch(p.stop)
		time = (start_str == stop_str) and "" or (start_str .. " - " .. stop_str .. "\n")
	end

    return raw .. "\n" ..
           time ..
           p.title ..
           (p.desc ~= "" and ("\n" .. wrap(p.desc, 60)) or "")
end

--local function build_msg(stream_name)
    --local xml = get_xml_path()
    --cache.data = cache.data or parse_xmltv(xml)
    --if not cache.data then
        --return "Cannot open XML: " .. xml
    --end
    --local p, raw, timing = find_prog(cache.data, stream_name)
    --if not p then return "No EPG match for: "..stream_name.." in "..xml end
    --local time = timing == "now" and fmt_epoch(p.start).." - "..fmt_epoch(p.stop).."\n" or ""
    --return raw.."\n"..time..p.title..(p.desc ~= "" and "\n"..wrap(p.desc, 60) or "")
--end

mp.add_key_binding("e", "show_epg", function()
	--todo - find a better way to disable cache, always use fresh search
	cache = {}
    local name = mp.get_property("media-title") or ""
    mp.osd_message(name ~= "" and build_msg(name) or "EPG: no stream", OSD_DURATION)
end)

mp.add_key_binding("E", "reload_epg", function()
    cache = {}
    local name = mp.get_property("media-title") or ""
    mp.osd_message(name ~= "" and build_msg(name) or "EPG: no stream", OSD_DURATION)
end)







mp.msg.info("plutotv_epg v2.4 loaded — e=show  E=reload+show")
