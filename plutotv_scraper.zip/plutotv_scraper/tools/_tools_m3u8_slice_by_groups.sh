#!/usr/bin/env bash

APPEND_INPUTFILE=0
PROCESS_ALL=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --append-inputfile)
            APPEND_INPUTFILE=1
            shift
            ;;
        --all)
            PROCESS_ALL=1
            shift
            ;;
        -*)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
        *)
            break
            ;;
    esac
done

process_file() {
    local INPUT_FILE="$1"

    if [[ ! -f "$INPUT_FILE" ]]; then
        echo "Error: File '$INPUT_FILE' not found." >&2
        return 1
    fi

    local BASENAME
    BASENAME=$(basename "$INPUT_FILE" .m3u8)
    local OUT_DIR="${BASENAME}_sliced"

    mkdir -p "$OUT_DIR"

    echo "Processing $INPUT_FILE..."
    echo "Output files will be saved in: ./$OUT_DIR/"

    awk -v RS='#EXTINF' -v outdir="$OUT_DIR" -v fname="$BASENAME" -v append="$APPEND_INPUTFILE" '
    NR > 1 {
        if (match($0, /group-title="([^"]+)"/, arr)) {
            group = arr[1]
        } else {
            group = "Uncategorized"
        }

        safe_group = group
        gsub(/[ \/\\?%*:"<>|]/, "_", safe_group)

        if (append == 1) {
            outfile = outdir "/" safe_group "_(" fname ").m3u8"
        } else {
            outfile = outdir "/" safe_group ".m3u8"
        }

        if (!seen[outfile]++) {
            print "#EXTM3U" > outfile
            close(outfile)
        }

        printf "#EXTINF%s", $0 >> outfile

        if ($0 !~ /\n$/) {
            printf "\n" >> outfile
        }

        close(outfile)
    }' "$INPUT_FILE"

    echo "Splitting complete! Look inside the '$OUT_DIR' directory."
}

if [[ "$PROCESS_ALL" -eq 1 ]]; then
    shopt -s nullglob
    files=( *.m3u8 )

    if [[ ${#files[@]} -eq 0 ]]; then
        echo "No .m3u8 files found in current directory." >&2
        exit 1
    fi

    for f in "${files[@]}"; do
        process_file "$f"
    done
else
    if [[ -z "$1" ]]; then
        echo "Usage: $0 [--append-inputfile] [--all] <file.m3u8>" >&2
        echo "       $0 --all [--append-inputfile]" >&2
        exit 1
    fi

    process_file "$1"
fi
