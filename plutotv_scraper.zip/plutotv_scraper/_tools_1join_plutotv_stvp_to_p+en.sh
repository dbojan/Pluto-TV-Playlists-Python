#!/bin/bash

#todo 
#fix plugins mpv, vlc
#upload to github



#options:
  #--config FILE         Path to config JSON file (default: config.json)
  #--mapping REGION,IP   Single region+IP override, e.g. us,45.50.96.71
  #--outdir DIR          Output directory
  #--clientid UUID       Pluto TV client ID (UUID)
  #--all                 Merge all regions into a single playlist/EPG
  #--chno N              Start channel numbering at N
  #--group MODE          Playlist grouping: genre or country
  #--regionalize         Append region code to channel IDs
  #--exclude-groups REGEX
                        #Exclude groups matching regex
  #--exclude-channels REGEX
                        #Exclude channels matching regex
  #--port N              Serve generated files on this port
  #--refresh SEC         Re-fetch interval in seconds (min 3600)
  #--unique-clientid     Generate unique client ID per server request
  #--random-clientid     Generate random client ID per request
  #--x-tvg-url URL       Custom x-tvg-url in EXTM3U header
  #--ondemand            Also generate on-demand movie playlists
  #--vlcopts             Add #EXTVLCOPT entries to M3U8
  #--pipeopts            Append piped headers to stream URLs
  #--json-source FILE    Public JSON file used as backup for regions where the
                        #live API returns no data
  #--append-expiry       Append #list updated / jwt expiry timestamps as
                        #comments to M3U8
  #-h, --help            Show this help message and exit
  #--no-xml              Skip writing XMLTV EPG files (very time-consuming),
                        #for channels only, not vod
  #--jwt-only            Only refresh JWT in existing .m3u8 files



#--jwt-only




#get channels (urls) and vod (urls, xml-epg) (noxml is for chanels only) once.
python plutotv_scraper.py --ondemand --config config_en.json --no-xml


##2nd time --jwt-only which will update just jwt, but wont search for new channels,  new vod movies.
#  python plutotv_scraper.py --config config_en.json --no-xml --jwt-only
##recreate live, and ondemand all
##do split againg, if you moved them

#merge all
#do not use --all, so you dont add it to itself
cd output
rm -f all*.*
all_ondemand=plutotv_ondemand_all.m3u8
cat plutotv_ondemand*.m3u8 > ${all_ondemand}

all_ondemand_xml=plutotv_ondemand_all.xml
cat plutotv_ondemand*.xml > ${all_ondemand_xml}

all_live=plutotv_live_all.m3u8
cat plutotv_live*.m3u8 > ${all_live}

all_live_xml=plutotv_live_all.xml
cat plutotv_live*.xml > ${all_live_xml}

#2nd time splite before deduplication, in output folder, if running in command line manually, add ./ before _tools... :  ./_tools_m3u8_slice_by_groups.sh --all --append-inputfile
_tools_m3u8_slice_by_groups.sh --all --append-inputfile

#2nd time 
python ./_tools_m3u8_title_sort__m3u8__.py --skip-url --all --skip-sorted --replace --no-backup

#copy to sony ftp, if you want.
ls /tmp/sony/ftp/
cp -r *.m3u8 /tmp/sony/ftp/outputok/

#update p+s-e: use create all_live; no need to sort again
psen=p+s-en.m3u
#all_live=plutotv_live_all.m3u8
cat ${all_live} ../stvp_new.m3u > ../${psen}




#GO UP FOLDER
cd ..





### ftp start
#ftp is in inetutils on void linux
#test if tools exist
for c in ftp
do
	if ! command -v $c >/dev/null
	then
		echo $c is missing
	fi
done



HOST1='bojan.mygamesonline.org'
USER1='4544578'
PASSWD1='banjaluka21'
ftpdir='bojan.mygamesonline.org'

#already defined up.
#psen="p+s-en.m3u"

#plutotv_ondemand_us.m3u8 is too big (30mb) :)
#gz is forbidden upload on mygamesonline, blocked :(
lists="$psen "



#fn filenametoupload
fn_ftp_upload() {
#-p means passive mode. if using manually command ftp without -p , use command 'pass' before put.
#do not indent :D
echo "uploading $1 to ftp ..." 
ftp -p -n "$HOST1" <<SCRIPT_MARKER
quote USER "$USER1"
quote PASS "$PASSWD1"
cd "$ftpdir"
binary
put "$1"
quit
SCRIPT_MARKER
}
#ftp must be defined before calling function later in script, like below

#no $ in for, cause it would think is string 'abc'
for list in $lists; do
	#echo "#Last Updated: $(date +%Y_%m_%d-%H_%M_%S)" >> "$list"
	echo "uploading $list"
	fn_ftp_upload "$list"
done

### ftp end



read -p 'done'


exit


