# plutotv-scraper — Codebase Spec

Python port of [4v3ngR/pluto_tv_scraper](https://github.com/4v3ngR/pluto_tv_scraper). Generates M3U8 playlists and XMLTV EPG files for Pluto TV across multiple regions. Zero external dependencies — pure stdlib.

**Requires:** Python 3.8+

---

## File Structure

```
plutotv_scraper.py     # Entry point, CLI argument parser, main()
config.json            # Default configuration file
lib/
  __init__.py
  config.py            # Config loader (file + CLI merge)
  api.py               # Pluto TV API client + M3U8/XMLTV generators
  plutotv.py           # Main orchestration loop
  ondemand.py          # VOD playlist + EPG generator
  server.py            # Built-in HTTP file server
  utils.py             # Shared helpers (UUID, HTML escape, M3U8/XMLTV merge)
```

---

## Module Responsibilities

### `plutotv_scraper.py`
Entry point. Builds the argparse parser, loads config, then dispatches to one of three modes:
- **Serve + refresh** — writes files, starts a background refresh thread, then serves.
- **Serve only** — serves pre-existing files.
- **One-shot** — calls `plutotv.process(cfg)` and exits.

### `lib/config.py` — `Config`
Loads `config.json` and merges CLI args on top (CLI wins). Normalises all keys to lowercase. Exposes `get(key)` and `get_mapping()`. Creates `outdir` on load.

Key config fields: `outdir`, `clientid`, `mapping` (region → IP), `group`, `regionalize`, `excludegroups`, `excludechannels`, `chno`, `port`, `refresh`, `xtvgurl`, `ondemand`, `vlcopts`, `pipeopts`, `jsonsource`, `appendexpiry`, `noxml`, `jwt_only`.

### `lib/api.py` — `PlutoAPI`
Stateful client for one region's fetch cycle. Call order matters:

```
api.boot(xff, client_id)      → authenticates, stores boot_data (JWT, stitcher URL)
api.channels(xff)             → fetches up to 1 000 channels
api.categories(xff)           → fetches channel categories
api.timelines(xff)            → fetches EPG in 4-hour windows, 30 channels/chunk
api.generate_m3u8(...)        → returns (m3u8_str, count)
api.generate_xmltv(...)       → returns xmltv_str
```

Also contains three standalone generator functions for fallback data sources:

| Function | Input | Use case |
|---|---|---|
| `generate_m3u8_from_json` | Pre-baked JSON region data | Live API returned 0 channels |
| `generate_xmltv_from_json` | Pre-baked JSON region data | Same |
| `generate_m3u8_from_ids` | Bare set of channel IDs | No metadata available |
| `generate_xmltv_from_ids` | Bare set of channel IDs | Same, no EPG emitted |

All stream URLs follow the pattern:
```
{stitcher}/v2{path}?{stitcherParams}&jwt={sessionToken}&masterJWTPassthrough=true
```

### `lib/plutotv.py` — `process(config)`
Iterates over `config.get_mapping()`. Per region:

1. Calls `api.boot()`, logs JWT expiry.
2. **`--jwt-only` mode** — patches JWT in existing `.m3u8` files via regex and skips all other work.
3. Otherwise: tries the live API. If it returns 0 channels, falls back to `--json-source` data.
4. Writes `plutotv_{region}.m3u8` and optionally `plutotv_{region}.xml`.
5. If `--ondemand`, runs `OnDemand` to write `plutotv_ondemand_{region}.{m3u8,xml}`.
6. After all regions: if `--all`, merges everything into `plutotv_all.{m3u8,xml}`.

### `lib/ondemand.py` — `OnDemand`
Fetches VOD categories and items from `service-vod.clusters.pluto.tv`. Filters to `type == "movie"` items only. Writes a cache file per region (`plutotv_ondemand_{region}.cache`) and reads it back to generate XMLTV. Channel numbering starts at 9000.

### `lib/server.py` — `serve(config)`
Minimal `http.server`-based file server. Serves files from `outdir` by filename only (path traversal blocked). For `.m3u8` requests, optionally re-boots with a per-request client ID and patches the JWT inline before responding (`--unique-clientid` / `--random-clientid`).

### `lib/utils.py`
- `escape_html(s)` — escapes `& < > ' "`.
- `get_time_str(dt)` → `YYYYMMDDHHmmss` UTC string for XMLTV timestamps.
- `make_uuid(data?)` — deterministic UUID from an IP string, or random UUID4.
- `merge_m3u8(playlists, x_tvg_url?)` — concatenates regional M3U8s, strips duplicate `#EXTM3U` headers.
- `merge_xmltv(epgs)` — merges regional XMLTV XML strings into one document.

---

## Data Flow

```
CLI / config.json
      │
      ▼
  Config.load()
      │
      ▼
plutotv.process()
  ├─ per region
  │    ├─ PlutoAPI.boot()          ← HTTPS to boot.pluto.tv
  │    ├─ PlutoAPI.channels()      ← HTTPS to service-channels
  │    ├─ PlutoAPI.categories()
  │    ├─ PlutoAPI.timelines()     ← skipped with --no-xml
  │    ├─ generate_m3u8 / xmltv
  │    └─ OnDemand (optional)      ← HTTPS to service-vod
  └─ merge all (optional)
        └─ merge_m3u8 / merge_xmltv
```

---

## Output Files

| File | Description |
|---|---|
| `plutotv_{region}.m3u8` | Live channel playlist for a region |
| `plutotv_{region}.xml` | XMLTV EPG for a region |
| `plutotv_ondemand_{region}.m3u8` | VOD playlist for a region |
| `plutotv_ondemand_{region}.xml` | VOD XMLTV for a region |
| `plutotv_ondemand_{region}.cache` | VOD item cache (JSON) |
| `plutotv_all.m3u8` | Merged playlist (all regions, `--all`) |
| `plutotv_all.xml` | Merged EPG (all regions, `--all`) |

---

## Key CLI Flags

| Flag | Effect |
|---|---|
| `--config FILE` | Alternative config file |
| `--mapping REGION,IP` | Single-region override |
| `--all` | Merge all regions |
| `--group genre\|country` | M3U8 `group-title` source |
| `--regionalize` | Append `-{region}` to channel IDs |
| `--no-xml` | Skip XMLTV generation |
| `--jwt-only` | Patch JWTs in existing files only |
| `--port N` | Start HTTP server on port N |
| `--refresh SEC` | Re-fetch interval (min 3600) |
| `--ondemand` | Also generate VOD playlists |
| `--json-source FILE` | JSON fallback for regions with no live data |
| `--append-expiry` | Add list-updated / JWT-expiry comments to M3U8 |
| `--vlcopts` | Add `#EXTVLCOPT` headers |
| `--pipeopts` | Append piped headers to stream URLs |
