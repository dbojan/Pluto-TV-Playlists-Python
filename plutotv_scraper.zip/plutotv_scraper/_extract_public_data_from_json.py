"""
extract_public_data_from_json.py

Reads a plu.json-format file and writes a cleaned version that is safe
to publish publicly (e.g. on GitHub) and remains valid indefinitely.

What is removed
---------------
  headers.x-forwarded-for  — real IP addresses used for geo-spoofing
  programs                 — absolute-timestamp EPG data; expires within hours

What is kept (stable, public, non-sensitive)
--------------------------------------------
  region: name, logo
  channel: chno, name, description, group, logo, art

Usage
-----
  python extract_public_data_from_json.py plu.json
  python extract_public_data_from_json.py plu.json --out custom_name.json

Output (default): <stem>_extracted_public_data.json
  e.g.  plu.json  →  plu_extracted_public_data.json
"""

import argparse
import json
import os
import sys


# Fields to keep at the channel level (everything else is dropped).
_CHANNEL_KEEP = {"chno", "name", "description", "group", "logo", "art"}


def extract(source: dict) -> dict:
    """Return a new dict with only public, non-stale data from a plu.json structure."""
    regions_out = {}

    for region_code, region_data in source.get("regions", {}).items():
        channels_out = {}
        for ch_id, ch in region_data.get("channels", {}).items():
            channels_out[ch_id] = {k: v for k, v in ch.items() if k in _CHANNEL_KEEP}

        region_out = {
            "name":     region_data.get("name", ""),
            "logo":     region_data.get("logo", ""),
            "channels": channels_out,
            # "headers" intentionally omitted (contains real IPs)
            # "programs" lives inside each channel and is already stripped above
        }
        regions_out[region_code] = region_out

    return {"regions": regions_out}


def default_output_name(input_path: str) -> str:
    """Derive default output path: <stem>_extracted_public_data.json"""
    stem = os.path.splitext(os.path.basename(input_path))[0]
    dirpart = os.path.dirname(input_path)
    filename = f"{stem}_extracted_public_data.json"
    return os.path.join(dirpart, filename) if dirpart else filename


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="extract_public_data_from_json",
        description=(
            "Strip sensitive / stale data from a plu.json file and write a "
            "clean version safe for public distribution."
        ),
    )
    p.add_argument(
        "input",
        metavar="INPUT.json",
        help="Source plu.json file to read",
    )
    p.add_argument(
        "--out",
        metavar="OUTPUT.json",
        default=None,
        help=(
            "Output file path "
            "(default: <stem>_extracted_public_data.json next to the input file)"
        ),
    )
    return p


def main():
    parser = build_parser()
    args = parser.parse_args()

    # Load
    try:
        with open(args.input, "r", encoding="utf-8") as fh:
            source = json.load(fh)
    except FileNotFoundError:
        print(f"ERROR: File not found: {args.input}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as exc:
        print(f"ERROR: Cannot parse {args.input}: {exc}", file=sys.stderr)
        sys.exit(1)

    if "regions" not in source:
        print("ERROR: No 'regions' key found — is this a valid plu.json file?", file=sys.stderr)
        sys.exit(1)

    # Extract
    output = extract(source)

    # Stats
    total_in = total_out = 0
    for r, rd in source["regions"].items():
        total_in += len(rd.get("channels", {}))
    for r, rd in output["regions"].items():
        total_out += len(rd.get("channels", {}))

    # Write
    out_path = args.out or default_output_name(args.input)
    try:
        with open(out_path, "w", encoding="utf-8") as fh:
            json.dump(output, fh, indent=2, ensure_ascii=False)
    except OSError as exc:
        print(f"ERROR: Cannot write {out_path}: {exc}", file=sys.stderr)
        sys.exit(1)

    print(f"Input:   {args.input}")
    print(f"Output:  {out_path}")
    print(f"Regions: {len(output['regions'])}")
    print(f"Channels: {total_out} (from {total_in} in source)")
    print()
    print("Stripped:  headers.x-forwarded-for (IP addresses)")
    print("Stripped:  programs (ephemeral EPG timestamps)")
    print()
    print("Safe to publish on GitHub or any public repository.")


if __name__ == "__main__":
    main()
