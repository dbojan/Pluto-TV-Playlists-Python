# plutotv-scraper (Python)

Python port of [4v3ngR/pluto_tv_scraper](https://github.com/4v3ngR/pluto_tv_scraper).

Generates **M3U8 playlists** and **XMLTV EPG** files for Pluto TV channels, with
multi-region support, optional on-demand (VOD) playlists, and a built-in HTTP
server that hot-refreshes JWT tokens per request.

---

## Requirements

- Python 3.8 +
- `aiohttp` (`pip install -r requirements.txt`)

---

## Quick start

```bash
# Install dependencies
pip install -r requirements.txt

# Edit config.json — set your own UUID as clientID
# Then generate files for all configured regions
python plutotv_scraper.py

# Single region override (no config.json needed)
python plutotv_scraper.py --mapping ca,23.227.38.65 --outdir ./output

# Serve files on port 8080 and auto-refresh every hour
python plutotv_scraper.py --port 8080 --refresh 3600
```

Output files are written to `outdir` (default: current directory):

| File | Description |
|---|---|
| `plutotv_<region>.m3u8` | Live-TV playlist for that region |
| `plutotv_<region>.xml`  | XMLTV EPG for that region |
| `plutotv_all.m3u8`      | Merged playlist (requires `--all`) |
| `plutotv_all.xml`       | Merged EPG (requires `--all`) |
| `plutotv_ondemand_<region>.m3u8` | VOD playlist (requires `--ondemand`) |
| `plutotv_ondemand_<region>.xml`  | VOD EPG (requires `--ondemand`) |

---

## All options

```
--config <FILE>            Config JSON file (default: config.json)
--mapping <REGION,IP>      Single region+IP override, e.g. us,45.50.96.71
--outdir <DIR>             Output directory (default: .)
--clientid <UUID>          Pluto TV client ID (UUID)
--all                      Merge all regions into plutotv_all.*
--chno <N>                 Start channel numbers at N (spans regions)
--group [genre|country]    Playlist group-title source (default: genre)
--regionalize              Append region code to channel IDs
--exclude-groups <REGEX>   Skip groups matching regex
--exclude-channels <REGEX> Skip channels matching regex
--port <N>                 Serve files on this port
--refresh <SEC>            Re-fetch interval in seconds (min 3600)
--unique-clientid          Generate unique client ID per server request
--random-clientid          Generate random client ID per server request
--x-tvg-url <URL>          Custom x-tvg-url in EXTM3U header
--ondemand                 Also generate VOD playlists
--vlcopts                  Add #EXTVLCOPT headers to M3U8
--pipeopts                 Append piped headers to stream URLs
-h / --help                Show help
```

---

## config.json reference

```json
{
  "outdir":         "./output",
  "clientID":       "your-uuid-here",
  "mapping": {
    "us": "45.50.96.71",
    "ca": "23.227.38.65"
  },
  "all":            false,
  "group":          "genre",
  "regionalize":    false,
  "excludeGroups":  false,
  "excludeChannels":false,
  "uniqueClientid": false,
  "randomClientid": false,
  "refresh":        0,
  "xTvgUrl":        false,
  "ondemand":       false,
  "vlcopts":        false,
  "pipeopts":       false
}
```

---

## Credits

Original JS project by [4v3ngR](https://github.com/4v3ngR/pluto_tv_scraper).  
EPG data by [matthuisman/i.mjh.nz](https://github.com/matthuisman/i.mjh.nz).
